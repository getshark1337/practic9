-- Physical SQLite schema generated from the validated demo database.
PRAGMA foreign_keys=ON;
BEGIN;

CREATE TABLE "app_users" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "password" varchar(128) NOT NULL, "last_login" datetime NULL, "is_superuser" bool NOT NULL, "username" varchar(150) NOT NULL UNIQUE, "first_name" varchar(150) NOT NULL, "last_name" varchar(150) NOT NULL, "is_staff" bool NOT NULL, "is_active" bool NOT NULL, "date_joined" datetime NOT NULL, "email" varchar(254) NOT NULL UNIQUE, "role" varchar(10) NOT NULL, "display_name" varchar(50) NOT NULL, CONSTRAINT "valid_user_role" CHECK ("role" IN ('admin', 'manager', 'user')));

CREATE TABLE "app_users_groups" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "user_id" integer NOT NULL REFERENCES "app_users" ("id") DEFERRABLE INITIALLY DEFERRED, "group_id" integer NOT NULL REFERENCES "auth_group" ("id") DEFERRABLE INITIALLY DEFERRED);

CREATE TABLE "app_users_user_permissions" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "user_id" integer NOT NULL REFERENCES "app_users" ("id") DEFERRABLE INITIALLY DEFERRED, "permission_id" integer NOT NULL REFERENCES "auth_permission" ("id") DEFERRABLE INITIALLY DEFERRED);

CREATE TABLE "applications" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "status" varchar(12) NOT NULL, "note" varchar(250) NOT NULL, "created_at" datetime NOT NULL, "reviewed_by_id" integer NULL REFERENCES "app_users" ("id") DEFERRABLE INITIALLY DEFERRED, "team_id" integer NOT NULL REFERENCES "teams" ("team_id") DEFERRABLE INITIALLY DEFERRED, "tournament_id" integer NOT NULL REFERENCES "tournament" ("tournament_id") DEFERRABLE INITIALLY DEFERRED, CONSTRAINT "one_team_application" UNIQUE ("tournament_id", "team_id"), CONSTRAINT "valid_application_status" CHECK ("status" IN ('pending', 'approved', 'rejected', 'withdrawn')));

CREATE TABLE "audit_log" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "action" varchar(32) NOT NULL, "entity" varchar(32) NOT NULL, "object_id" integer unsigned NOT NULL CHECK ("object_id" >= 0), "description" varchar(250) NOT NULL, "created_at" datetime NOT NULL, "actor_id" integer NULL REFERENCES "app_users" ("id") DEFERRABLE INITIALLY DEFERRED);

CREATE TABLE "auth_group" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "name" varchar(150) NOT NULL UNIQUE);

CREATE TABLE "auth_group_permissions" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "group_id" integer NOT NULL REFERENCES "auth_group" ("id") DEFERRABLE INITIALLY DEFERRED, "permission_id" integer NOT NULL REFERENCES "auth_permission" ("id") DEFERRABLE INITIALLY DEFERRED);

CREATE TABLE "auth_permission" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "content_type_id" integer NOT NULL REFERENCES "django_content_type" ("id") DEFERRABLE INITIALLY DEFERRED, "codename" varchar(100) NOT NULL, "name" varchar(255) NOT NULL);

CREATE TABLE "django_admin_log" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "object_id" text NULL, "object_repr" varchar(200) NOT NULL, "action_flag" smallint unsigned NOT NULL CHECK ("action_flag" >= 0), "change_message" text NOT NULL, "content_type_id" integer NULL REFERENCES "django_content_type" ("id") DEFERRABLE INITIALLY DEFERRED, "user_id" integer NOT NULL REFERENCES "app_users" ("id") DEFERRABLE INITIALLY DEFERRED, "action_time" datetime NOT NULL);

CREATE TABLE "django_content_type" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "app_label" varchar(100) NOT NULL, "model" varchar(100) NOT NULL);

CREATE TABLE "django_migrations" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "app" varchar(255) NOT NULL, "name" varchar(255) NOT NULL, "applied" datetime NOT NULL);

CREATE TABLE "django_session" ("session_key" varchar(40) NOT NULL PRIMARY KEY, "session_data" text NOT NULL, "expire_date" datetime NOT NULL);

CREATE TABLE "games" ("game_id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "name" varchar(100) NOT NULL, "genre" varchar(50) NULL, "developer" varchar(100) NULL, "release_date" date NULL);

CREATE TABLE "map_scores" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "number" smallint unsigned NOT NULL CHECK ("number" >= 0), "score1" smallint unsigned NOT NULL CHECK ("score1" >= 0), "score2" smallint unsigned NOT NULL CHECK ("score2" >= 0), "map_id" integer NOT NULL REFERENCES "maps" ("id") DEFERRABLE INITIALLY DEFERRED, "match_id" integer NOT NULL REFERENCES "matches" ("match_id") DEFERRABLE INITIALLY DEFERRED, CONSTRAINT "unique_map_number" UNIQUE ("match_id", "number"), CONSTRAINT "unique_match_map" UNIQUE ("match_id", "map_id"), CONSTRAINT "valid_map_score" CHECK (("score1" <= 60 AND "score2" <= 60 AND NOT ("score1" = ("score2")))));

CREATE TABLE "maps" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "name" varchar(32) NOT NULL UNIQUE);

CREATE TABLE "matches" ("match_id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "match_date" datetime NULL, "stage" varchar(50) NULL, "team1_id" integer NULL REFERENCES "teams" ("team_id") DEFERRABLE INITIALLY DEFERRED, "team2_id" integer NULL REFERENCES "teams" ("team_id") DEFERRABLE INITIALLY DEFERRED, "tournament_id" integer NOT NULL REFERENCES "tournament" ("tournament_id") DEFERRABLE INITIALLY DEFERRED, "round_number" smallint unsigned NULL CHECK ("round_number" >= 0), "slot" smallint unsigned NULL CHECK ("slot" >= 0), "status" varchar(12) NOT NULL, CONSTRAINT "different_opponents" CHECK (NOT ("team1_id" = ("team2_id") AND "team1_id" IS NOT NULL AND "team2_id" IS NOT NULL)), CONSTRAINT "unique_bracket_slot" UNIQUE ("tournament_id", "round_number", "slot"), CONSTRAINT "valid_match_status" CHECK ("status" IN ('scheduled', 'live', 'finished')));

CREATE TABLE "organization" ("organization_id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "name" varchar(100) NOT NULL, "address" varchar(200) NULL, "phone" varchar(20) NULL, "email" varchar(100) NULL);

CREATE TABLE "player_stats" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "kills" smallint unsigned NOT NULL CHECK ("kills" >= 0), "deaths" smallint unsigned NOT NULL CHECK ("deaths" >= 0), "assists" smallint unsigned NOT NULL CHECK ("assists" >= 0), "match_id" integer NOT NULL REFERENCES "matches" ("match_id") DEFERRABLE INITIALLY DEFERRED, "player_id" integer NOT NULL REFERENCES "players" ("player_id") DEFERRABLE INITIALLY DEFERRED, CONSTRAINT "one_player_stat_per_match" UNIQUE ("match_id", "player_id"));

CREATE TABLE "players" ("player_id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "nickname" varchar(50) NOT NULL UNIQUE, "full_name" varchar(100) NULL, "birth_date" date NULL, "country" varchar(50) NULL, "team_id" integer NULL REFERENCES "teams" ("team_id") DEFERRABLE INITIALLY DEFERRED, "position" varchar(10) NOT NULL);

CREATE TABLE "result" ("result_id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "score_team1" integer NOT NULL, "score_team2" integer NOT NULL, "match_id" integer NOT NULL UNIQUE REFERENCES "matches" ("match_id") DEFERRABLE INITIALLY DEFERRED, "winner_team_id" integer NULL REFERENCES "teams" ("team_id") DEFERRABLE INITIALLY DEFERRED, CONSTRAINT "score1_nonnegative" CHECK ("score_team1" >= 0), CONSTRAINT "score2_nonnegative" CHECK ("score_team2" >= 0));

CREATE TABLE "teams" ("team_id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "name" varchar(100) NOT NULL, "country" varchar(50) NULL, "coach" varchar(100) NULL, "game_id" integer NULL REFERENCES "games" ("game_id") DEFERRABLE INITIALLY DEFERRED, "owner_id" integer NULL REFERENCES "app_users" ("id") DEFERRABLE INITIALLY DEFERRED, "points" integer unsigned NOT NULL CHECK ("points" >= 0), "tag" varchar(8) NULL UNIQUE);

CREATE TABLE "tournament" ("tournament_id" integer NOT NULL PRIMARY KEY AUTOINCREMENT, "name" varchar(100) NOT NULL, "start_date" date NULL, "end_date" date NULL, "prize_pool" decimal NOT NULL, "organization_id" integer NULL REFERENCES "organization" ("organization_id") DEFERRABLE INITIALLY DEFERRED, "best_of" smallint unsigned NOT NULL CHECK ("best_of" >= 0), "capacity" smallint unsigned NOT NULL CHECK ("capacity" >= 0), "description" text NOT NULL, "game_id" integer NULL REFERENCES "games" ("game_id") DEFERRABLE INITIALLY DEFERRED, "manager_id" integer NULL REFERENCES "app_users" ("id") DEFERRABLE INITIALLY DEFERRED, "region" varchar(12) NOT NULL, "status" varchar(16) NOT NULL, CONSTRAINT "nonnegative_prize" CHECK ("prize_pool" >= '0'), CONSTRAINT "tournament_date_order" CHECK (("end_date" IS NULL OR "start_date" IS NULL OR "end_date" >= ("start_date"))), CONSTRAINT "valid_capacity" CHECK ("capacity" IN (8, 16, 32)), CONSTRAINT "valid_best_of" CHECK ("best_of" IN (1, 3)), CONSTRAINT "valid_tournament_status" CHECK ("status" IN ('draft', 'registration', 'ongoing', 'finished')));

CREATE INDEX "app_users_groups_group_id_b415af26" ON "app_users_groups" ("group_id");

CREATE INDEX "app_users_groups_user_id_0e9dac45" ON "app_users_groups" ("user_id");

CREATE UNIQUE INDEX "app_users_groups_user_id_group_id_8831fa58_uniq" ON "app_users_groups" ("user_id", "group_id");

CREATE INDEX "app_users_user_permissions_permission_id_2479a5e1" ON "app_users_user_permissions" ("permission_id");

CREATE INDEX "app_users_user_permissions_user_id_eb741ab8" ON "app_users_user_permissions" ("user_id");

CREATE UNIQUE INDEX "app_users_user_permissions_user_id_permission_id_c4e82b6d_uniq" ON "app_users_user_permissions" ("user_id", "permission_id");

CREATE INDEX "applications_reviewed_by_id_a3821166" ON "applications" ("reviewed_by_id");

CREATE INDEX "applications_team_id_9428eb95" ON "applications" ("team_id");

CREATE INDEX "applications_tournament_id_41382b06" ON "applications" ("tournament_id");

CREATE INDEX "audit_log_actor_id_dfa07704" ON "audit_log" ("actor_id");

CREATE INDEX "auth_group_permissions_group_id_b120cbf9" ON "auth_group_permissions" ("group_id");

CREATE UNIQUE INDEX "auth_group_permissions_group_id_permission_id_0cd325b0_uniq" ON "auth_group_permissions" ("group_id", "permission_id");

CREATE INDEX "auth_group_permissions_permission_id_84c5c92e" ON "auth_group_permissions" ("permission_id");

CREATE INDEX "auth_permission_content_type_id_2f476e4b" ON "auth_permission" ("content_type_id");

CREATE UNIQUE INDEX "auth_permission_content_type_id_codename_01ab375a_uniq" ON "auth_permission" ("content_type_id", "codename");

CREATE INDEX "django_admin_log_content_type_id_c4bce8eb" ON "django_admin_log" ("content_type_id");

CREATE INDEX "django_admin_log_user_id_c564eba6" ON "django_admin_log" ("user_id");

CREATE UNIQUE INDEX "django_content_type_app_label_model_76bd3d3b_uniq" ON "django_content_type" ("app_label", "model");

CREATE INDEX "django_session_expire_date_a5c62663" ON "django_session" ("expire_date");

CREATE INDEX "map_scores_map_id_4778f836" ON "map_scores" ("map_id");

CREATE INDEX "map_scores_match_id_2a221276" ON "map_scores" ("match_id");

CREATE INDEX "matches_team1_id_7d18cbe0" ON "matches" ("team1_id");

CREATE INDEX "matches_team2_id_a6be4f57" ON "matches" ("team2_id");

CREATE INDEX "matches_tournament_id_8b59e12c" ON "matches" ("tournament_id");

CREATE INDEX "player_stats_match_id_8a843887" ON "player_stats" ("match_id");

CREATE INDEX "player_stats_player_id_2832e897" ON "player_stats" ("player_id");

CREATE INDEX "players_team_id_8b821f35" ON "players" ("team_id");

CREATE INDEX "result_winner_team_id_9502035d" ON "result" ("winner_team_id");

CREATE INDEX "teams_game_id_32ccd020" ON "teams" ("game_id");

CREATE INDEX "teams_owner_id_d02bfe57" ON "teams" ("owner_id");

CREATE INDEX "tournament_game_id_cbf8529a" ON "tournament" ("game_id");

CREATE INDEX "tournament_manager_id_0f512621" ON "tournament" ("manager_id");

CREATE INDEX "tournament_organization_id_e8329cfb" ON "tournament" ("organization_id");

CREATE UNIQUE INDEX "unique_lower_email" ON "app_users" ((LOWER("email")));

CREATE TRIGGER trg_frag_result_insert
              BEFORE INSERT ON result WHEN NEW.winner_team_id IS NOT NULL AND NOT EXISTS (
                SELECT 1 FROM matches m WHERE m.match_id=NEW.match_id AND (
                  (NEW.winner_team_id=m.team1_id AND NEW.score_team1>NEW.score_team2) OR
                  (NEW.winner_team_id=m.team2_id AND NEW.score_team2>NEW.score_team1)
                )
              ) BEGIN SELECT RAISE(ABORT, 'Invalid match winner or score'); END;

CREATE TRIGGER trg_frag_result_update
              BEFORE UPDATE ON result WHEN NEW.winner_team_id IS NOT NULL AND NOT EXISTS (
                SELECT 1 FROM matches m WHERE m.match_id=NEW.match_id AND (
                  (NEW.winner_team_id=m.team1_id AND NEW.score_team1>NEW.score_team2) OR
                  (NEW.winner_team_id=m.team2_id AND NEW.score_team2>NEW.score_team1)
                )
              ) BEGIN SELECT RAISE(ABORT, 'Invalid match winner or score'); END;

COMMIT;
