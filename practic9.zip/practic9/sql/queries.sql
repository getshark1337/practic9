-- PostgreSQL. Имена :parameter обозначают параметры, которые приложение
-- передаёт отдельно. В psycopg используйте %(name)s и словарь значений.
-- Для ручного запуска заменяйте параметры значениями в pgAdmin.

-- 1. Поиск по нескольким полям и фильтрация по статусу/региону/формату.
SELECT t.tournament_id, t.name, o.name AS organizer, t.start_date,
       t.status, t.region, t.best_of, t.prize_pool
FROM tournament t
LEFT JOIN organization o ON o.organization_id=t.organization_id
WHERE (t.name ILIKE :search OR o.name ILIKE :search)
  AND (:status IS NULL OR t.status=:status)
  AND (:region IS NULL OR t.region=:region)
  AND (:best_of IS NULL OR t.best_of=:best_of)
ORDER BY t.prize_pool DESC, t.start_date ASC, t.name ASC;

-- 2. Команды: поиск по названию/тегу/тренеру, страна и дисциплина.
SELECT team_id, name, tag, country, points FROM teams
WHERE (name ILIKE :search OR tag ILIKE :search OR coach ILIKE :search)
  AND (:country IS NULL OR country=:country)
  AND (:game_id IS NULL OR game_id=:game_id)
ORDER BY points DESC, name ASC;

-- 3. Состав команды.
SELECT player_id, nickname, full_name, position, country
FROM players WHERE team_id=:team_id ORDER BY position, nickname;

-- 4. Игроки: никнейм/ФИО/команда и несколько критериев сортировки.
SELECT p.player_id, p.nickname, p.full_name, tm.name AS team,
       COALESCE(SUM(ps.kills),0) AS kills,
       COALESCE(SUM(ps.deaths),0) AS deaths, COUNT(ps.id) AS series
FROM players p
LEFT JOIN teams tm ON tm.team_id=p.team_id
LEFT JOIN player_stats ps ON ps.player_id=p.player_id
WHERE p.nickname ILIKE :search OR p.full_name ILIKE :search OR tm.name ILIKE :search
GROUP BY p.player_id, tm.name
ORDER BY kills DESC, p.nickname ASC;

-- 5. Матчи с командами и результатами, включая будущие TBD.
SELECT m.match_id, t.name AS tournament, a.name AS team1, b.name AS team2,
       m.stage, m.round_number, m.slot, m.match_date, m.status,
       r.score_team1, r.score_team2, w.name AS winner
FROM matches m
JOIN tournament t ON t.tournament_id=m.tournament_id
LEFT JOIN teams a ON a.team_id=m.team1_id
LEFT JOIN teams b ON b.team_id=m.team2_id
LEFT JOIN result r ON r.match_id=m.match_id
LEFT JOIN teams w ON w.team_id=r.winner_team_id
WHERE m.tournament_id=:tournament_id
ORDER BY m.round_number, m.slot;

-- 6. Рассмотрение заявок. Реальное изменение выполняется сервисом
-- с проверкой менеджера, вместимости, дисциплины и состава в транзакции.
SELECT a.id, tm.name, a.status, a.created_at,
       (SELECT COUNT(*) FROM players p WHERE p.team_id=tm.team_id) AS roster_size
FROM applications a JOIN teams tm ON tm.team_id=a.team_id
WHERE a.tournament_id=:tournament_id ORDER BY a.created_at, a.id;

-- 7. Карты матча.
SELECT ms.number, mp.name, ms.score1, ms.score2
FROM map_scores ms JOIN maps mp ON mp.id=ms.map_id
WHERE ms.match_id=:match_id ORDER BY ms.number;

-- 8. Победитель турнира по последнему раунду.
SELECT tm.team_id, tm.name FROM matches m
JOIN result r ON r.match_id=m.match_id
JOIN teams tm ON tm.team_id=r.winner_team_id
WHERE m.tournament_id=:tournament_id
ORDER BY m.round_number DESC NULLS LAST LIMIT 1;

-- 9. Пример параметризованного изменения справочника.
UPDATE organization SET name=:name, email=:email
WHERE organization_id=:organization_id;

-- 10. Подсчёт записей исходных таблиц.
SELECT (SELECT COUNT(*) FROM organization) AS organizations,
       (SELECT COUNT(*) FROM games) AS games,
       (SELECT COUNT(*) FROM teams) AS teams,
       (SELECT COUNT(*) FROM players) AS players,
       (SELECT COUNT(*) FROM tournament) AS tournaments,
       (SELECT COUNT(*) FROM matches) AS matches,
       (SELECT COUNT(*) FROM result) AS results;

-- 11. Рейтинг по учебным очкам; количество побед.
SELECT tm.team_id, tm.name, tm.points, COUNT(r.result_id) AS wins
FROM teams tm LEFT JOIN result r ON r.winner_team_id=tm.team_id
GROUP BY tm.team_id ORDER BY tm.points DESC, wins DESC, tm.name ASC;

-- 12. Текущие заявки капитана.
SELECT a.id, t.name AS tournament, tm.name AS team, a.status
FROM applications a JOIN teams tm ON tm.team_id=a.team_id
JOIN tournament t ON t.tournament_id=a.tournament_id
WHERE tm.owner_id=:user_id ORDER BY a.created_at DESC;

-- 13. Состояние очередного места в сетке (сервер вычисляет round/slot).
SELECT match_id, team1_id, team2_id, status
FROM matches WHERE tournament_id=:tournament_id
AND round_number=:next_round AND slot=:next_slot FOR UPDATE;
