from django.contrib import admin
from django.urls import include, path

urlpatterns = [path('admin/', admin.site.urls), path('', include('arena.urls'))]
handler403 = 'arena.views.error_403'
handler404 = 'arena.views.error_404'
