"""Check record preservation when --fake-initial upgrades the legacy 7 tables.
This is a SQLite compatibility check; PostgreSQL 18 coverage is defined in CI.
"""
import os
import sqlite3
import subprocess
import sys
import tempfile
from pathlib import Path

root=Path(__file__).resolve().parent.parent
tables=['organization','games','teams','players','tournament','matches','result']
with tempfile.TemporaryDirectory(prefix='frag-legacy-') as tmp:
    path=Path(tmp)/'legacy.sqlite3'
    db=sqlite3.connect(path)
    ddl=(root/'tables').read_text().split('CREATE OR REPLACE FUNCTION')[0]
    ddl=ddl.replace('SERIAL PRIMARY KEY','INTEGER PRIMARY KEY AUTOINCREMENT')
    db.executescript(ddl)
    for n in range(1,101):
        db.execute('INSERT INTO organization(organization_id,name) VALUES (?,?)',[n,f'Original org {n}'])
        db.execute('INSERT INTO games(game_id,name) VALUES (?,?)',[n,f'Original game {n}'])
        db.execute('INSERT INTO teams(team_id,name,game_id) VALUES (?,?,?)',[n,f'Original team {n}',1])
        db.execute('INSERT INTO players(player_id,team_id,nickname) VALUES (?,?,?)',[n,n,f'legacy_{n}'])
        db.execute('INSERT INTO tournament(tournament_id,organization_id,name) VALUES (?,?,?)',[n,n,f'Original cup {n}'])
        db.execute('INSERT INTO matches(match_id,tournament_id,team1_id,team2_id) VALUES (?,?,?,?)',[n,n,1,2])
        db.execute('INSERT INTO result(result_id,match_id,winner_team_id,score_team1,score_team2) VALUES (?,?,?,?,?)',[n,n,1,2,0])
    db.commit()
    before={t:db.execute(f'SELECT * FROM {t} ORDER BY 1').fetchall() for t in tables}
    old_columns={t:[c[1] for c in db.execute(f'PRAGMA table_info({t})')] for t in tables}
    db.close()
    env=os.environ.copy()
    env.pop('DATABASE_URL',None)
    env['DATABASE_URL']=''
    env['SQLITE_PATH']=str(path)
    subprocess.run([sys.executable,'manage.py','migrate','--fake-initial','--noinput'],cwd=root,env=env,check=True,stdout=subprocess.DEVNULL)
    db=sqlite3.connect(path)
    for table in tables:
        columns=','.join(old_columns[table])
        after=db.execute(f'SELECT {columns} FROM {table} ORDER BY 1').fetchall()
        assert before[table]==after, f'Legacy data changed: {table}'
    assert db.execute("SELECT COUNT(*) FROM tournament WHERE status='finished'").fetchone()[0]==100
    db.close()
    print('Legacy SQLite upgrade: all 700 original records and original columns preserved.')
