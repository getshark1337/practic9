"""Generate exact SVG diagrams and editable draw.io files; no external assets."""
from pathlib import Path
from xml.sax.saxutils import escape
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent.parent/'docs'


def render(name,title,subtitle,width,height,nodes,edges,notes):
    parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<defs><marker id="arrow" markerWidth="10" markerHeight="10" refX="9" refY="5" orient="auto"><path d="M0 0L10 5L0 10Z" fill="#647f9a"/></marker></defs>',
        '<rect width="100%" height="100%" fill="#f4f7fb"/>',
        f'<text x="40" y="44" font-family="Arial, sans-serif" font-size="25" font-weight="700" fill="#122b45">{escape(title)}</text>',
        f'<text x="40" y="75" font-family="Arial, sans-serif" font-size="14" fill="#526b83">{escape(subtitle)}</text>']
    for points,label in edges:
        coords=' '.join(f'{x},{y}' for x,y in points)
        parts.append(f'<polyline points="{coords}" fill="none" stroke="#647f9a" stroke-width="2" marker-end="url(#arrow)"/>')
        x,y=points[len(points)//2]
        x,y,anchor=x+9,y-9,'start'
        if len(points)==2:
            a,b=points
            x,y=(a[0]+b[0])/2,(a[1]+b[1])/2
            if a[1]==b[1]: y-=12; anchor='middle'
            else: x+=9
        if label=='журнал действий': x,y,anchor=width-100,1490,'end'
        parts.append(f'<text x="{x}" y="{y}" text-anchor="{anchor}" font-family="Arial, sans-serif" font-size="12" fill="#486780">{escape(label)}</text>')
    for key,node in nodes.items():
        x,y,w,heading,fields=node
        h=48+len(fields)*26
        parts += [f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="10" fill="#ffffff" stroke="#c4d2e1" stroke-width="1.5"/>',
            f'<path d="M{x+10} {y}H{x+w-10}Q{x+w} {y} {x+w} {y+10}V{y+42}H{x}V{y+10}Q{x} {y} {x+10} {y}" fill="#183c5c"/>',
            f'<text x="{x+17}" y="{y+27}" font-family="Arial, sans-serif" font-size="16" font-weight="700" fill="#ffffff">{escape(heading)}</text>']
        for i,field in enumerate(fields):
            parts.append(f'<text x="{x+17}" y="{y+65+i*26}" font-family="Arial, sans-serif" font-size="13" fill="#253f56">{escape(field)}</text>')
    for i,note in enumerate(notes):
        parts.append(f'<text x="40" y="{height-55+i*22}" font-family="Arial, sans-serif" font-size="13" fill="#526b83">{escape(note)}</text>')
    parts.append('</svg>')
    (ROOT/f'{name}.svg').write_text('\n'.join(parts),encoding='utf-8')
    mx=ET.Element('mxfile',host='app.diagrams.net')
    diagram=ET.SubElement(mx,'diagram',id=name,name=title)
    model=ET.SubElement(diagram,'mxGraphModel',dx=str(width),dy=str(height),grid='1',page='1',pageWidth=str(width),pageHeight=str(height))
    root=ET.SubElement(model,'root')
    ET.SubElement(root,'mxCell',id='0');ET.SubElement(root,'mxCell',id='1',parent='0')
    cell=ET.SubElement(root,'mxCell',id='title',value=title,vertex='1',parent='1',style='text;html=0;fontSize=24;fontStyle=1;align=left;')
    ET.SubElement(cell,'mxGeometry',x='40',y='15',width=str(width-80),height='55',**{'as':'geometry'})
    for key,(x,y,w,heading,fields) in nodes.items():
        cell=ET.SubElement(root,'mxCell',id=key,value=heading+'\n\n'+'\n'.join(fields),vertex='1',parent='1',style='rounded=1;whiteSpace=wrap;html=0;fillColor=#ffffff;strokeColor=#8ca7c0;fontColor=#183c5c;fontSize=14;align=left;verticalAlign=top;spacing=14;')
        ET.SubElement(cell,'mxGeometry',x=str(x),y=str(y),width=str(w),height=str(48+len(fields)*26),**{'as':'geometry'})
    for i,(points,label) in enumerate(edges):
        cell=ET.SubElement(root,'mxCell',id=f'edge{i}',value=label,edge='1',parent='1',style='endArrow=block;html=0;strokeColor=#647f9a;rounded=0;')
        for end,point in [('source',points[0]),('target',points[-1])]:
            for key,(nx,ny,nw,_,fields) in nodes.items():
                nh=48+len(fields)*26
                px,py=point
                if nx<=px<=nx+nw and ny<=py<=ny+nh and (px in (nx,nx+nw) or py in (ny,ny+nh)):
                    cell.set(end,key)
                    prefix='exit' if end=='source' else 'entry'
                    cell.set('style',cell.get('style')+f'{prefix}X={(px-nx)/nw};{prefix}Y={(py-ny)/nh};{prefix}Perimeter=0;')
                    break
        geo=ET.SubElement(cell,'mxGeometry',relative='1',**{'as':'geometry'})
        ET.SubElement(geo,'mxPoint',x=str(points[0][0]),y=str(points[0][1]),**{'as':'sourcePoint'})
        ET.SubElement(geo,'mxPoint',x=str(points[-1][0]),y=str(points[-1][1]),**{'as':'targetPoint'})
        arr=ET.SubElement(geo,'Array',**{'as':'points'})
        for x,y in points[1:-1]: ET.SubElement(arr,'mxPoint',x=str(x),y=str(y))
    ET.ElementTree(mx).write(ROOT/f'{name}.drawio',encoding='utf-8',xml_declaration=True)


concept={
 'org':(40,130,360,'Организация',['Проводит турниры']),
 'tournament':(510,130,360,'Турнир',['Название, сроки, формат, призовой фонд']),
 'game':(980,130,360,'Дисциплина',['Counter-Strike 2 / справочник']),
 'application':(40,430,360,'Заявка',['Команда + турнир + решение менеджера']),
 'match':(510,430,360,'Матч',['Две команды, стадия, время']),
 'team':(980,430,360,'Команда',['Капитан, страна, состав, рейтинг']),
 'user':(40,730,360,'Аккаунт',['Пользователь / менеджер / администратор']),
 'result':(510,730,360,'Результат',['Счёт серии и победитель']),
 'player':(980,730,360,'Игрок',['Никнейм, ФИО, страна, позиция']),
}
cedges=[
 ([(400,167),(510,167)],'1 : N'),
 ([(980,167),(870,167)],'1 : N'),
 ([(1160,204),(1160,430)],'1 : N'),
 ([(690,204),(690,430)],'1 : N'),
 ([(980,467),(870,467)],'2 FK'),
 ([(1160,504),(1160,730)],'1 : N'),
 ([(690,504),(690,730)],'1 : 0..1'),
 ([(510,190),(455,190),(455,467),(400,467)],'1 : N'),
 ([(1030,430),(1030,360),(220,360),(220,430)],'1 : N'),
 ([(220,730),(220,504)],'подаёт'),
]
render('conceptual','FRAG / Концептуальная модель','Предметная область: организация турнира, участие команды и публикация результата.',1380,970,concept,cedges,[
 'Матч дополнительно содержит результаты карт и статистику игроков; действия аккаунтов фиксируются в журнале.',
 'Все предметные таблицы и FK представлены на логической схеме и в database.md.'])

logical={
 'org':(40,130,450,'organization',['PK organization_id : integer','name : varchar(100) NOT NULL','address, phone, email']),
 'game':(660,130,450,'games',['PK game_id : integer','name : varchar(100) NOT NULL','genre, developer, release_date']),
 'user':(1280,130,450,'app_users',['PK id : integer','username, email : UNIQUE','password : Django hash','role : admin | manager | user','display_name, is_active']),
 'tournament':(40,460,450,'tournament',['PK tournament_id : integer','FK organization_id → organization','FK manager_id → app_users','FK game_id → games','name, start_date, end_date','prize_pool : numeric(12,2) ≥ 0','capacity : 8 | 16 | 32','best_of : 1 | 3; status, region']),
 'team':(660,460,450,'teams',['PK team_id : integer','FK game_id → games','FK owner_id → app_users','name, tag UNIQUE, country, coach','points : integer ≥ 0']),
 'player':(1280,460,450,'players',['PK player_id : integer','FK team_id → teams','nickname : UNIQUE','full_name, birth_date, country','position : fixed choices']),
 'match':(40,850,450,'matches',['PK match_id : integer','FK tournament_id → tournament','FK team1_id → teams (nullable TBD)','FK team2_id → teams (nullable TBD)','match_date, stage, status','round_number, slot','UNIQUE (tournament_id, round_number, slot)','CHECK team1_id ≠ team2_id']),
 'application':(660,850,450,'applications',['PK id : integer','FK tournament_id → tournament','FK team_id → teams','FK reviewed_by_id → app_users','status, note, created_at','UNIQUE (tournament_id, team_id)']),
 'stat':(1280,850,450,'player_stats',['PK id : integer','FK match_id → matches','FK player_id → players','kills, deaths, assists : 0–200','UNIQUE (match_id, player_id)']),
 'result':(40,1220,450,'result',['PK result_id : integer','FK match_id → matches UNIQUE','FK winner_team_id → teams','score_team1, score_team2 ≥ 0','TRIGGER validates winner and score']),
 'mapscore':(660,1220,450,'map_scores',['PK id : integer','FK match_id → matches','FK map_id → maps','number, score1, score2','UNIQUE (match_id, number)','UNIQUE (match_id, map_id)']),
 'maps':(1280,1220,450,'maps',['PK id : integer','name : varchar(32) UNIQUE']),
 'audit':(1280,1540,450,'audit_log',['PK id : integer','FK actor_id → app_users (nullable)','action, entity, object_id','description, created_at']),
}
ledges=[
 ([(265,256),(265,460)],'1 : N'),
 ([(885,256),(885,460)],'1 : N'),
 ([(660,200),(560,200),(560,400),(400,400),(400,460)],'дисциплина'),
 ([(1280,200),(1180,200),(1180,400),(1020,400),(1020,460)],'капитан'),
 ([(1110,550),(1280,550)],'1 : N'),
 ([(265,716),(265,850)],'1 : N'),
 ([(885,638),(885,850)],'1 : N'),
 ([(1505,638),(1505,850)],'1 : N'),
 ([(265,1106),(265,1220)],'1 : 0..1'),
 ([(490,1000),(560,1000),(560,1310),(660,1310)],'1 : N'),
 ([(1280,1290),(1110,1290)],'1 : N'),
 ([(490,660),(600,660),(600,940),(660,940)],'1 : N'),
 ([(660,590),(530,590),(530,810),(400,810),(400,850)],'team1 / team2'),
 ([(1730,230),(1780,230),(1780,770),(510,770),(510,690),(490,690)],'менеджер турнира'),
 ([(400,1106),(400,1160),(1505,1160),(1505,1028)],'статистика серии'),
 ([(1730,280),(1800,280),(1800,1620),(1730,1620)],'журнал действий'),
]
render('logical','FRAG / Логическая модель','PK — первичный ключ; FK → целевая таблица. Исходные семь таблиц сохранены, подсистемы приложения добавлены.',1840,1810,logical,ledges,[
 'FK внутри карточек задают полный состав связей; стрелки показывают основные связи между сущностями.',
 'Служебные таблицы Django (сессии, миграции, права, история администратора) перечислены в database.md.'])
print('Created conceptual/logical SVG and draw.io diagrams.')
