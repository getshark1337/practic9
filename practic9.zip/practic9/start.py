"""One-command local setup for Windows, Linux and macOS. Python 3.10+."""
import os
import subprocess
import sys
import venv
from pathlib import Path

ROOT=Path(__file__).resolve().parent
os.chdir(ROOT)
if sys.version_info < (3,10):
    raise SystemExit('Нужен Python 3.10 или новее.')
environment=ROOT/'.venv'
executable=environment/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
if not executable.exists():
    print('Создаём виртуальное окружение…',flush=True)
    venv.create(environment,with_pip=True)
try:
    if '--no-install' not in sys.argv:
        subprocess.run([str(executable),'-m','pip','install','-r','requirements.txt'],check=True)
    subprocess.run([str(executable),'manage.py','migrate','--fake-initial'],check=True)
    subprocess.run([str(executable),'manage.py','seed_demo'],check=True)
    print('\nFRAG: http://127.0.0.1:8000/ — остановка Ctrl+C\n',flush=True)
    subprocess.run([str(executable),'manage.py','runserver','127.0.0.1:8000'],check=True)
except KeyboardInterrupt:
    pass
except subprocess.CalledProcessError as error:
    raise SystemExit(f'Команда завершилась с ошибкой {error.returncode}. Проверьте сообщение выше.')
