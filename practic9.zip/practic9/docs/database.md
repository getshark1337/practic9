# Модели и физическая структура БД

## Концептуальная модель

Организация проводит турниры. Игра задаёт дисциплину турнира и команды. Команда содержит игроков и подаёт заявку на турнир. Турнир состоит из матчей; две команды участвуют в каждом определившемся матче. Матч имеет не более одного результата, результаты отдельных карт и статистику игроков. Аккаунт пользователя владеет командами, аккаунт менеджера ведёт турниры. Действия фиксируются в журнале.

Схемы: [conceptual.svg](conceptual.svg), [logical.svg](logical.svg). Редактируемые версии: `.drawio` с теми же именами. Изначальные PNG сохранены в корне репозитория как исторические материалы; актуальные связи приведены здесь.

## Логическая модель

| Откуда | Куда | Кардинальность / смысл |
|---|---|---|
| organization | tournament | 1 : N, организатор турниров |
| games | teams, tournament | 1 : N, дисциплина |
| app_users | teams | 1 : N, капитан команды |
| app_users | tournament | 1 : N, менеджер турнира |
| teams | players | 1 : N, текущий состав |
| teams ↔ tournament | applications | N : M через заявку; одна заявка команды на турнир |
| tournament | matches | 1 : N, матчи сетки |
| teams | matches | Две независимые FK: team1_id и team2_id |
| matches | result | 1 : 0..1; result.match_id уникален |
| matches | map_scores | 1 : N, сыгранные карты |
| maps | map_scores | 1 : N, справочник карт |
| matches ↔ players | player_stats | N : M; одна запись статистики игрока за серию |
| app_users | audit_log | 1 : N; при удалении аккаунта журнал остаётся |

## Физическая модель и ключи

Поддерживаются PostgreSQL (основная СУБД исходного проекта) и SQLite для локальной демонстрации. Автоматически назначаемый целочисленный PK не передаётся в редактируемые поля форм. Суффикс `_id` у ForeignKey обозначает реальную колонку БД.

| Таблица | Первичный ключ | Основные поля и внешние ключи |
|---|---|---|
| organization | organization_id | name VARCHAR(100), address VARCHAR(200), phone VARCHAR(20), email VARCHAR(100) |
| games | game_id | name VARCHAR(100), genre VARCHAR(50), developer VARCHAR(100), release_date DATE |
| teams | team_id | name VARCHAR(100), country VARCHAR(50), coach VARCHAR(100), tag VARCHAR(8) UNIQUE, points INTEGER; game_id → games, owner_id → app_users |
| players | player_id | nickname VARCHAR(50) UNIQUE, full_name VARCHAR(100), birth_date DATE, country VARCHAR(50), position VARCHAR(10); team_id → teams |
| tournament | tournament_id | name VARCHAR(100), start_date/end_date DATE, prize_pool NUMERIC(12,2), status VARCHAR(16), capacity SMALLINT, best_of SMALLINT, region VARCHAR(12); organization_id → organization, manager_id → app_users, game_id → games |
| matches | match_id | tournament_id → tournament, team1_id/team2_id → teams, match_date DATETIME / TIMESTAMPTZ, stage VARCHAR(50), round_number/slot SMALLINT, status VARCHAR(12) |
| result | result_id | match_id → matches UNIQUE, winner_team_id → teams, score_team1/score_team2 INTEGER |
| app_users | id | username VARCHAR(150) UNIQUE, email UNIQUE, display_name VARCHAR(50), role VARCHAR(10), password VARCHAR(128), active/staff flags, dates |
| applications | id | tournament_id → tournament, team_id → teams, reviewed_by_id → app_users, status VARCHAR(12), note VARCHAR(250), created_at |
| maps | id | name VARCHAR(32) UNIQUE |
| map_scores | id | match_id → matches, map_id → maps, number SMALLINT, score1/score2 SMALLINT |
| player_stats | id | match_id → matches, player_id → players, kills/deaths/assists SMALLINT |
| audit_log | id | actor_id → app_users, action/entity VARCHAR(32), object_id INTEGER, description VARCHAR(250), created_at |

Служебные таблицы Django: миграции, сессии, типы контента, права, группы и журнал администратора. Прикладные роли определяются полем `app_users.role`; дополнительные роли не создаются через группы.

## Домены и ограничения

| Поле / правило | Допустимые значения | Где контролируется |
|---|---|---|
| Роль | admin / manager / user | Choices, CHECK, серверная авторизация |
| Статус турнира | draft / registration / ongoing / finished | CHECK + транзакционные переходы |
| Размер сетки | 8 / 16 / 32 | Выпадающий список + CHECK |
| Формат серии | 1 / 3 | Выпадающий список + CHECK |
| Призовой фонд | ≥ 0; окончание ≥ начала | Валидатор / CHECK |
| Статус матча | scheduled / live / finished | Choices + CHECK |
| Участники матча | team1 ≠ team2; TBD допускается до определения победителей | FK, CHECK, сервис результата |
| Страна | Значения списка COUNTRIES | ChoiceField; исторические значения исходной БД сохраняются |
| Регион | online / europe / cis / asia / americas | ChoiceField |
| Позиция игрока | rifler / awper / igl / support / entry | ChoiceField |
| Тег команды | 2–8 ASCII букв/цифр, верхний регистр | Форма; UNIQUE в БД |
| Заявка | pending / approved / rejected / withdrawn | CHECK; UNIQUE(tournament_id, team_id) |
| Место в сетке | UNIQUE(tournament_id, round_number, slot) | UNIQUE; для исторических матчей значения NULL |
| Результат | Счёт неотрицательный, победитель участвует и имеет больший счёт | CHECK + триггер обеих СУБД |
| Счёт карты CS2 | MR12: 13:0–11; OT: 16:12–14, 19:15–17 и т. д. до 58 | Сервис; лимиты полей и CHECK от 0 до 60, без ничьей |
| Карты в серии | Уникальные карта и порядковый номер; после решающей карты серия заканчивается | UNIQUE + сервис |
| Статистика | K/D/A 0–200; один игрок один раз за серию | Формы / валидаторы; UNIQUE(match_id, player_id) |
| Дата рождения | Не позже текущей даты | Форма |

Обязательные поля пользовательских форм обозначены `*`. Некоторые старые столбцы остаются nullable для совместимости с исходной БД; новые записи приложения требуют организатора, дисциплину, даты и полный состав перед участием.

## Переходы и согласованность

Турнир: `draft → registration → ongoing → finished`. Завершение происходит после сохранения финала. Заявка: `pending → approved / rejected`; `pending / approved → withdrawn` до посева; отозванную можно подать повторно. Генерация сетки и сохранение результата выполняются внутри `transaction.atomic`. В PostgreSQL турнир блокируется `SELECT FOR UPDATE`, последующие связанные действия сериализуются. SQLite рассчитан на локальную демонстрацию; для одновременной работы организаторов используйте PostgreSQL.

В раунде `r` находится `capacity / 2^r` матчей. Победитель матча с позицией `s` попадает в матч `ceil(s/2)` следующего раунда: нечётная позиция — команда 1, чётная — команда 2. Победитель финала читается из `result`, не дублируется отдельной колонкой.

Текущий состав команды фиксируется при её участии в идущем турнире. В статистике сохраняются ссылки на игроков, без исторических снимков названий и составов; отдельная история трансферов не входит в первую версию.

## Исходная БД и миграции

`arena/0001_initial` соответствует исходным семи таблицам из файла `tables`. `accounts/0001_initial` создаёт аккаунты отдельно, что позволяет распознать исходные таблицы при `--fake-initial`.

- `arena/0002…` добавляет поля приложения и новые предметные таблицы.
- `arena/0003…` помечает старые матчи с результатом завершёнными, определяет состояние старых турниров и устанавливает триггер результата.
- `arena/0004…` защищает организаторов от удаления через приложение при наличии турниров.
- `arena/0005…` приводит только старый PostgreSQL `TIMESTAMP without time zone` к `TIMESTAMPTZ`.

**Предположение о времени:** исходные значения без часового пояса считаются локальным временем Екатеринбурга. Если ваша старая БД хранит их в другом поясе, скорректируйте эту единственную константу в миграции 0005 до первого применения к копии своей БД. На свежей БД PostgreSQL и на SQLite эта операция ничего не меняет.

Миграции не удаляют исходные строки. На старых матчах нет данных о связях раундов, поэтому приложение не придумывает их автоматически. Старые команды и турниры можно назначить капитанам и менеджерам через администратора.

Фактический DDL текущей SQLite БД: [../sql/schema-sqlite.sql](../sql/schema-sqlite.sql). Для PostgreSQL DDL воспроизводится `python manage.py sqlmigrate arena <номер>` при подключении к PostgreSQL; выполняйте миграции через `manage.py migrate`.
