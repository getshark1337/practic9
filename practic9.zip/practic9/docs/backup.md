# Резервное копирование и восстановление

## Исходный файл

`dbackup.sql` начинается с сигнатуры `PGDMP`: это PostgreSQL custom dump, а не SQL-текст. В заголовке указаны сервер 18.6 и `pg_dump` 18.4. Для проверки и восстановления используйте утилиты PostgreSQL 18. Утилита 16.2 не читает формат 1.16 этого файла.

Сначала восстанавливайте в новую БД, чтобы проверить результат:

```bash
createdb -U postgres esports_legacy
pg_restore -U postgres --no-owner --no-acl -d esports_legacy dbackup.sql
```

После восстановления укажите эту БД в `.env` и выполните `python manage.py migrate --fake-initial`. В pgAdmin используйте действие Restore с форматом Custom. Исходный файл не изменяется.

## Создание новой копии

```bash
python manage.py backup_db
```

Команда создаёт файл с датой и временем в `backups/`. Можно указать назначение:

```bash
python manage.py backup_db backups/before-demo.sqlite3
```

Для PostgreSQL укажите имя с расширением `.dump` и установите `pg_dump` той же основной версии, что сервер, либо новее. Пароль передаётся дочернему процессу через `PGPASSWORD`, не через аргументы командной строки. PostgreSQL режим создаёт custom dump. SQLite использует штатный Backup API и согласованный снимок.

Администратор также скачивает копию через `/cabinet/ → Backup БД`. У пользователя и менеджера этот маршрут возвращает 403. Копия включает аккаунты и хеши паролей, поэтому хранится как административный файл.

## Восстановление SQLite

1. Остановите приложение.
2. Сохраните текущий `db.sqlite3` под другим именем.
3. Скопируйте проверенный `.sqlite3` backup в корень проекта под именем `db.sqlite3`.
4. Выполните `python manage.py migrate`, затем `python manage.py runserver`.

Проверка файла средствами Python:

```bash
python -c "import sqlite3; c=sqlite3.connect('db.sqlite3'); print(c.execute('PRAGMA integrity_check').fetchone())"
```

Ожидается `('ok',)`. В архив проекта может входить новая учебная копия `backups/arena-demo.sqlite3`; она содержит только синтетические данные. Оригинальный PostgreSQL backup остаётся самостоятельным историческим файлом и не заменяется этой копией.
