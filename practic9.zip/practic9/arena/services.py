"""All tournament transitions are transactional and authorized on the server."""
import math
import random
from datetime import datetime, time, timedelta
from django.core.exceptions import PermissionDenied, ValidationError
from django.db import transaction
from django.utils import timezone
from .models import Application, AuditLog, Match, MapScore, Result, Team, Tournament


def audit(user, action, obj, description):
    AuditLog.objects.create(actor=user, action=action, entity=obj._meta.model_name,
                            object_id=obj.pk, description=description[:250])


def require_manager(user, tournament):
    if not tournament.editable_by(user):
        raise PermissionDenied('Управлять турниром может его менеджер или администратор.')


@transaction.atomic
def apply_to_tournament(user, tournament_id, team_id, note=''):
    t = Tournament.objects.select_for_update().get(pk=tournament_id)
    team = Team.objects.select_for_update().get(pk=team_id)
    if team.owner_id != user.pk:
        raise PermissionDenied('Заявку может подать только капитан своей команды.')
    if t.status != 'registration':
        raise ValidationError('Приём заявок на этот турнир закрыт.')
    if t.game_id and team.game_id != t.game_id:
        raise ValidationError('Игра команды должна совпадать с дисциплиной турнира.')
    if team.players.count() < 5:
        raise ValidationError('Для участия добавьте в команду не менее пяти игроков.')
    app, created = Application.objects.get_or_create(tournament=t, team=team, defaults={'note': note})
    if not created:
        if app.status != 'withdrawn':
            raise ValidationError('Эта команда уже подала заявку на турнир.')
        app.status, app.note, app.reviewed_by = 'pending', note, None
        app.save()
    audit(user, 'apply', app, f'{team.name}: заявка на {t.name}')
    return app


@transaction.atomic
def review_application(user, application_id, status):
    # Lock the tournament before an application, consistently with seeding.
    t_id = Application.objects.values_list('tournament_id', flat=True).get(pk=application_id)
    t = Tournament.objects.select_for_update().get(pk=t_id)
    require_manager(user, t)
    app = Application.objects.select_for_update().select_related('team').get(pk=application_id)
    if t.status != 'registration':
        raise ValidationError('Рассматривать заявки можно только до формирования сетки.')
    if status not in ('approved', 'rejected') or app.status not in ('pending', 'approved'):
        raise ValidationError('Недопустимый переход статуса заявки.')
    if app.status == status:
        raise ValidationError('Заявка уже имеет этот статус.')
    if status == 'approved':
        if t.game_id and app.team.game_id != t.game_id:
            raise ValidationError('Дисциплина команды не совпадает с турниром.')
        if app.team.players.count() < 5:
            raise ValidationError('В составе должно быть не менее пяти игроков.')
        if t.applications.filter(status='approved').count() >= t.capacity:
            raise ValidationError('Все места в сетке уже заняты.')
    app.status, app.reviewed_by = status, user
    app.save(update_fields=['status', 'reviewed_by'])
    audit(user, 'review', app, f'Заявка {app.team}: {app.get_status_display()}')


@transaction.atomic
def withdraw_application(user, application_id):
    t_id = Application.objects.values_list('tournament_id', flat=True).get(pk=application_id)
    t = Tournament.objects.select_for_update().get(pk=t_id)
    app = Application.objects.select_for_update().select_related('team').get(pk=application_id)
    if app.team.owner_id != user.pk and not user.is_admin:
        raise PermissionDenied('Это заявка другой команды.')
    if t.status != 'registration' or app.status not in ('pending', 'approved'):
        raise ValidationError('Отозвать заявку можно до формирования сетки.')
    app.status = 'withdrawn'
    app.save(update_fields=['status'])
    audit(user, 'withdraw', app, 'Заявка отозвана')


@transaction.atomic
def open_registration(user, tournament_id):
    t = Tournament.objects.select_for_update().get(pk=tournament_id)
    require_manager(user, t)
    if t.status != 'draft':
        raise ValidationError('Регистрацию можно открыть только у черновика.')
    t.status = 'registration'
    t.save(update_fields=['status'])
    audit(user, 'registration', t, 'Открыт приём заявок')


def seed_order(size):
    order = [1, 2]
    while len(order) < size:
        total = len(order) * 2 + 1
        order = [n for value in order for n in (value, total - value)]
    return [n - 1 for n in order]


@transaction.atomic
def generate_bracket(user, tournament_id, method='rating'):
    t = Tournament.objects.select_for_update().get(pk=tournament_id)
    require_manager(user, t)
    if t.status != 'registration' or t.matches.exists():
        raise ValidationError('Сетку можно сформировать один раз после приёма заявок.')
    teams = list(Team.objects.select_for_update().filter(applications__tournament=t, applications__status='approved').order_by('-points', 'name', 'pk'))
    if len(teams) != t.capacity:
        raise ValidationError(f'Для сетки нужны ровно {t.capacity} одобренных заявок. Сейчас: {len(teams)}.')
    if any(team.players.count() < 5 for team in teams):
        raise ValidationError('Проверьте составы: в каждой команде должно быть не менее пяти игроков.')
    if t.game_id and any(team.game_id != t.game_id for team in teams):
        raise ValidationError('Проверьте дисциплину команд турнира.')
    if method == 'random':
        random.SystemRandom().shuffle(teams)
    elif method != 'rating':
        raise ValidationError('Выберите посев по рейтингу или случайный посев.')
    teams = [teams[i] for i in seed_order(t.capacity)]
    rounds = int(math.log2(t.capacity))
    base = timezone.make_aware(datetime.combine(t.start_date or timezone.localdate(), time(18)))
    matches = []
    for r in range(1, rounds + 1):
        count = t.capacity // (2 ** r)
        stage = {1: 'Финал', 2: 'Полуфинал', 4: 'Четвертьфинал'}.get(count, f'1/{count} финала')
        for slot in range(1, count + 1):
            matches.append(Match(tournament=t, round_number=r, slot=slot, stage=stage,
                team1=teams[(slot-1)*2] if r == 1 else None,
                team2=teams[(slot-1)*2+1] if r == 1 else None,
                match_date=base+timedelta(days=r-1, minutes=(slot-1)*90)))
    Match.objects.bulk_create(matches)
    t.status = 'ongoing'
    t.save(update_fields=['status'])
    audit(user, 'bracket', t, f'Сформирована сетка на {t.capacity} команд')


def validate_map_results(best_of, maps):
    if not 1 <= len(maps) <= best_of:
        raise ValidationError(f'Укажите от 1 до {best_of} сыгранных карт.')
    if len({row['map'].pk for row in maps}) != len(maps):
        raise ValidationError('Одна карта не может повторяться в матче.')
    wins = [0, 0]
    target = best_of // 2 + 1
    for i, row in enumerate(maps):
        a, b = row['score1'], row['score2']
        hi, lo = max(a, b), min(a, b)
        # CS2 MR12 with overtime in sets of six rounds.
        valid_score = (hi == 13 and lo <= 11) or (16 <= hi <= 58 and (hi-16) % 3 == 0 and hi-4 <= lo <= hi-2)
        if a < 0 or b < 0 or not valid_score:
            raise ValidationError(f'Карта {i+1}: допустим счёт 13:0–11 или овертайм 16:12–14, 19:15–17 и далее.')
        wins[0 if a > b else 1] += 1
        if max(wins) == target and i != len(maps)-1:
            raise ValidationError('После победы в серии дополнительные карты не проводятся.')
    if max(wins) != target:
        raise ValidationError(f'Для завершения BO{best_of} команда должна выиграть {target} карт(ы).')
    return wins


@transaction.atomic
def record_result(user, match_id, maps):
    t_id = Match.objects.values_list('tournament_id', flat=True).get(pk=match_id)
    t = Tournament.objects.select_for_update().get(pk=t_id)
    require_manager(user, t)
    m = Match.objects.select_for_update().get(pk=match_id)
    if not m.team1_id or not m.team2_id:
        raise ValidationError('Сначала должны определиться оба участника матча.')
    if m.status == 'finished' and not user.is_admin:
        raise PermissionDenied('Исправление завершённого матча доступно администратору.')
    if t.status not in ('ongoing', 'finished'):
        raise ValidationError('Турнир ещё не начался.')
    next_match = None
    if m.round_number and m.slot:
        next_match = Match.objects.select_for_update().filter(tournament=t, round_number=m.round_number+1, slot=(m.slot+1)//2).first()
    if next_match and (next_match.status != 'scheduled' or hasattr(next_match, 'result')):
        raise ValidationError('Следующий матч уже начался. Исправление изменит сыгранную сетку.')
    scores = validate_map_results(t.best_of, maps)
    winner_id = m.team1_id if scores[0] > scores[1] else m.team2_id
    Result.objects.update_or_create(match=m, defaults={'winner_team_id': winner_id, 'score_team1': scores[0], 'score_team2': scores[1]})
    m.map_scores.all().delete()
    MapScore.objects.bulk_create([MapScore(match=m, number=i+1, **row) for i, row in enumerate(maps)])
    m.status = 'finished'
    m.save(update_fields=['status'])
    if next_match:
        field = 'team1_id' if m.slot % 2 else 'team2_id'
        setattr(next_match, field, winner_id)
        next_match.save(update_fields=[field.removesuffix('_id')])
    elif m.round_number and 2 ** m.round_number == t.capacity:
        t.status = 'finished'
        t.save(update_fields=['status'])
    audit(user, 'result', m, f'Результат: {scores[0]}:{scores[1]}; победитель #{winner_id}')
    return m
