from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import ValidationError
from django.utils import timezone
from accounts.models import User
from .models import COUNTRIES, Team, Player, Tournament, Match, Map, PlayerStat


class RegisterForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'display_name', 'email', 'password1', 'password2']
        labels = {'username': 'Логин'}
    def clean_email(self):
        value = self.cleaned_data['email'].lower()
        if User.objects.filter(email__iexact=value).exists():
            raise ValidationError('Пользователь с такой почтой уже зарегистрирован.')
        return value
    def clean_username(self):
        value = self.cleaned_data['username'].lower()
        if User.objects.filter(username__iexact=value).exists():
            raise ValidationError('Этот логин уже занят.')
        return value
    def save(self, commit=True):
        user = super().save(commit=False)
        user.role = User.Role.USER  # A role submitted by the browser is never trusted.
        if commit: user.save()
        return user


class TeamForm(forms.ModelForm):
    country = forms.ChoiceField(label='Страна', choices=COUNTRIES)
    class Meta:
        model = Team
        fields = ['name', 'tag', 'country', 'coach', 'game']
    def clean_tag(self):
        value = (self.cleaned_data.get('tag') or '').strip().upper()
        if not 2 <= len(value) <= 8 or not value.isalnum() or not value.isascii():
            raise ValidationError('Тег: от 2 до 8 латинских букв или цифр.')
        return value
    def clean_game(self):
        game = self.cleaned_data.get('game')
        if not game: raise ValidationError('Выберите дисциплину.')
        if self.instance.pk and self.instance.applications.exclude(status__in=['withdrawn', 'rejected']).exists() and game.pk != self.instance.game_id:
            raise ValidationError('Нельзя менять дисциплину команды с действующими заявками.')
        return game


class PlayerForm(forms.ModelForm):
    country = forms.ChoiceField(label='Страна', choices=COUNTRIES)
    class Meta:
        model = Player
        fields = ['nickname', 'full_name', 'birth_date', 'country', 'position']
        widgets = {'birth_date': forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d')}
    def clean_birth_date(self):
        date = self.cleaned_data.get('birth_date')
        if date and date > timezone.localdate():
            raise ValidationError('Дата рождения не может быть в будущем.')
        return date


class TournamentForm(forms.ModelForm):
    class Meta:
        model = Tournament
        fields = ['name', 'organization', 'game', 'start_date', 'end_date', 'prize_pool', 'capacity', 'best_of', 'region', 'description']
        widgets = {'start_date': forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'),
                   'end_date': forms.DateInput(attrs={'type': 'date'}, format='%Y-%m-%d'),
                   'description': forms.Textarea(attrs={'rows': 4})}
    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        for name in ['organization', 'game', 'start_date', 'end_date']:
            self.fields[name].required = True
        if user and user.is_admin:
            self.fields['manager'] = forms.ModelChoiceField(label='Менеджер', queryset=User.objects.filter(role__in=['admin', 'manager'], is_active=True), initial=self.instance.manager_id or user.pk)
        if self.instance.pk:
            if self.instance.applications.exists(): self.fields['game'].disabled = True
            if self.instance.status in ('ongoing', 'finished'):
                for name in ['capacity', 'best_of', 'game']:
                    self.fields[name].disabled = True
    def clean(self):
        data = super().clean()
        if data.get('start_date') and data.get('end_date') and data['end_date'] < data['start_date']:
            self.add_error('end_date', 'Окончание должно быть не раньше начала.')
        if self.instance.pk and data.get('capacity') and self.instance.applications.filter(status='approved').count() > data['capacity']:
            self.add_error('capacity', 'Уже одобрено больше команд. Сначала пересмотрите заявки.')
        return data


class AdminPlayerForm(PlayerForm):
    class Meta(PlayerForm.Meta):
        fields = PlayerForm.Meta.fields + ['team']
    def clean(self):
        data=super().clean()
        old_team=Player.objects.select_related('team').get(pk=self.instance.pk).team if self.instance.pk else None
        new_team=data.get('team')
        if (old_team and old_team.roster_locked) or (new_team and new_team.roster_locked):
            raise ValidationError('Нельзя менять игрока или состав команды во время идущего турнира.')
        return data


class ApplicationForm(forms.Form):
    team = forms.ModelChoiceField(label='Ваша команда', queryset=Team.objects.none())
    note = forms.CharField(label='Комментарий', max_length=250, required=False)
    def __init__(self, *args, user, tournament, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['team'].queryset = Team.objects.filter(owner=user, game_id=tournament.game_id).order_by('name')


class MapResultForm(forms.Form):
    map = forms.ModelChoiceField(label='Карта', queryset=Map.objects.all().order_by('name'), required=False)
    score1 = forms.IntegerField(label='Раунды команды 1', min_value=0, max_value=60, required=False)
    score2 = forms.IntegerField(label='Раунды команды 2', min_value=0, max_value=60, required=False)
    def clean(self):
        data = super().clean()
        values = [data.get('map'), data.get('score1'), data.get('score2')]
        if any(value is not None for value in values) and any(value is None for value in values):
            raise ValidationError('Выберите карту и укажите оба значения счёта или оставьте всю строку пустой.')
        return data


class MatchScheduleForm(forms.ModelForm):
    class Meta:
        model = Match
        fields = ['match_date', 'status']
        widgets = {'match_date': forms.DateTimeInput(attrs={'type': 'datetime-local'}, format='%Y-%m-%dT%H:%M')}
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['status'].choices = [('scheduled', 'Предстоит'), ('live', 'Идёт')]
    def clean_status(self):
        value = self.cleaned_data['status']
        if value == 'live' and not (self.instance.team1_id and self.instance.team2_id):
            raise ValidationError('Матч можно начать после определения обоих участников.')
        return value


class StatForm(forms.ModelForm):
    class Meta:
        model = PlayerStat
        fields = ['player', 'kills', 'deaths', 'assists']
    def __init__(self, *args, match, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['player'].queryset = Player.objects.filter(team_id__in=[match.team1_id, match.team2_id]).order_by('nickname')
