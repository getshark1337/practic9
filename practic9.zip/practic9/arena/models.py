"""The first migration reproduces the seven tables already in `tables`."""
from django.db import models
from django.db.models import Q, F
from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.validators import MaxValueValidator, MinValueValidator

COUNTRIES = [(c, c) for c in ['Россия', 'Казахстан', 'Беларусь', 'Сербия', 'Германия', 'Франция', 'Бразилия', 'Дания', 'Швеция', 'США', 'Китай', 'Турция', 'Финляндия', 'Великобритания', 'Другая']]
REGIONS = [('online', 'Online'), ('europe', 'Европа'), ('cis', 'СНГ'), ('asia', 'Азия'), ('americas', 'Америка')]


class Organization(models.Model):
    id = models.AutoField(primary_key=True, db_column='organization_id')
    name = models.CharField('Название', max_length=100)
    address = models.CharField('Адрес', max_length=200, blank=True, null=True)
    phone = models.CharField('Телефон', max_length=20, blank=True, null=True)
    email = models.EmailField('Почта', max_length=100, blank=True, null=True)
    class Meta:
        db_table = 'organization'
        verbose_name = 'организатор'
        verbose_name_plural = 'организаторы'
    def __str__(self): return self.name


class Game(models.Model):
    id = models.AutoField(primary_key=True, db_column='game_id')
    name = models.CharField('Название', max_length=100)
    genre = models.CharField('Жанр', max_length=50, blank=True, null=True)
    developer = models.CharField('Разработчик', max_length=100, blank=True, null=True)
    release_date = models.DateField('Дата выхода', blank=True, null=True)
    class Meta:
        db_table = 'games'
        verbose_name = 'игра'
        verbose_name_plural = 'игры'
    def __str__(self): return self.name


class Team(models.Model):
    id = models.AutoField(primary_key=True, db_column='team_id')
    name = models.CharField('Название', max_length=100)
    country = models.CharField('Страна', max_length=50, blank=True, null=True)
    coach = models.CharField('Тренер', max_length=100, blank=True, null=True)
    game = models.ForeignKey(Game, db_column='game_id', on_delete=models.SET_NULL, blank=True, null=True, verbose_name='Игра')
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, null=True, blank=True, related_name='teams', verbose_name='Капитан')
    tag = models.CharField('Тег', max_length=8, unique=True, null=True, blank=True)
    points = models.PositiveIntegerField('Рейтинговые очки', default=0)
    captain = models.ForeignKey('Player', on_delete=models.SET_NULL, null=True, blank=True, related_name='captain_of_teams', verbose_name='Капитан')
    class Meta:
        db_table = 'teams'
        verbose_name = 'команда'
        verbose_name_plural = 'команды'
    def __str__(self): return self.name
    def editable_by(self, user):
        return user.is_authenticated and (user.is_admin or self.owner_id == user.pk)
    @property
    def roster_locked(self):
        return self.applications.filter(status='approved', tournament__status='ongoing').exists()


class Player(models.Model):
    id = models.AutoField(primary_key=True)
    team = models.ForeignKey(Team, db_column='team_id', on_delete=models.SET_NULL, blank=True, null=True, related_name='players', verbose_name='Команда')
    nickname = models.CharField('Никнейм', max_length=50, unique=True)
    full_name = models.CharField('ФИО', max_length=100, blank=True, null=True)
    birth_date = models.DateField('Дата рождения', blank=True, null=True)
    country = models.CharField('Страна', max_length=50, blank=True, null=True)
    position = models.CharField('Роль в игре', max_length=10, choices=[('rifler', 'Rifler'), ('awper', 'AWPer'), ('igl', 'IGL'), ('support', 'Support'), ('entry', 'Entry')], default='rifler')
    class Meta:
        db_table = 'players'
        verbose_name = 'игрок'
        verbose_name_plural = 'игроки'
    def __str__(self): return self.nickname


class Tournament(models.Model):
    class Status(models.TextChoices):
        DRAFT = 'draft', 'Черновик'
        REGISTRATION = 'registration', 'Приём заявок'
        ONGOING = 'ongoing', 'Идёт'
        FINISHED = 'finished', 'Завершён'
    id = models.AutoField(primary_key=True, db_column='tournament_id')
    organization = models.ForeignKey(Organization, db_column='organization_id', on_delete=models.PROTECT, blank=True, null=True, verbose_name='Организатор')
    name = models.CharField('Название', max_length=100)
    start_date = models.DateField('Начало', blank=True, null=True)
    end_date = models.DateField('Окончание', blank=True, null=True)
    prize_pool = models.DecimalField('Призовой фонд, ₽', max_digits=12, decimal_places=2, default=0)
    manager = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, blank=True, null=True, related_name='tournaments', verbose_name='Менеджер')
    game = models.ForeignKey(Game, on_delete=models.PROTECT, null=True, blank=True, verbose_name='Игра')
    status = models.CharField('Статус', max_length=16, choices=Status.choices, default=Status.DRAFT)
    capacity = models.PositiveSmallIntegerField('Команд в сетке', choices=[(8, '8'), (16, '16'), (32, '32')], default=8)
    best_of = models.PositiveSmallIntegerField('Формат матчей', choices=[(1, 'BO1'), (3, 'BO3')], default=3)
    region = models.CharField('Регион', max_length=12, choices=REGIONS, default='online')
    description = models.TextField('Описание', max_length=3000, blank=True)
    class Meta:
        db_table = 'tournament'
        verbose_name = 'турнир'
        verbose_name_plural = 'турниры'
        constraints = [
            models.CheckConstraint(condition=Q(prize_pool__gte=0), name='nonnegative_prize'),
            models.CheckConstraint(condition=Q(end_date__isnull=True)|Q(start_date__isnull=True)|Q(end_date__gte=F('start_date')), name='tournament_date_order'),
            models.CheckConstraint(condition=Q(capacity__in=[8, 16, 32]), name='valid_capacity'),
            models.CheckConstraint(condition=Q(best_of__in=[1, 3]), name='valid_best_of'),
            models.CheckConstraint(condition=Q(status__in=['draft', 'registration', 'ongoing', 'finished']), name='valid_tournament_status'),
        ]
    def __str__(self): return self.name
    def editable_by(self, user):
        return user.is_authenticated and user.can_manage and (user.is_admin or self.manager_id == user.pk)


class Match(models.Model):
    id = models.AutoField(primary_key=True)
    tournament = models.ForeignKey(Tournament, db_column='tournament_id', on_delete=models.CASCADE, related_name='matches', verbose_name='Турнир')
    team1 = models.ForeignKey(Team, db_column='team1_id', on_delete=models.PROTECT, null=True, blank=True, related_name='matches_as_first', verbose_name='Команда 1')
    team2 = models.ForeignKey(Team, db_column='team2_id', on_delete=models.PROTECT, null=True, blank=True, related_name='matches_as_second', verbose_name='Команда 2')
    match_date = models.DateTimeField('Время матча', blank=True, null=True)
    round_number = models.PositiveSmallIntegerField('Номер раунда', null=True, blank=True)
    slot = models.PositiveSmallIntegerField('Номер матча в раунде', null=True, blank=True)
    status = models.CharField('Статус', max_length=12, choices=[('scheduled', 'Предстоит'), ('live', 'Идёт'), ('finished', 'Завершён')], default='scheduled')
    class Meta:
        db_table = 'matches'
        verbose_name = 'матч'
        verbose_name_plural = 'матчи'
        constraints = [
            models.CheckConstraint(condition=~Q(team1=F('team2')), name='different_opponents'),
            models.UniqueConstraint(fields=['tournament', 'round_number', 'slot'], name='unique_bracket_slot'),
            models.CheckConstraint(condition=Q(status__in=['scheduled', 'live', 'finished']), name='valid_match_status'),
        ]
    def __str__(self): return f'{self.team1 or "TBD"} — {self.team2 or "TBD"}'


class Result(models.Model):
    id = models.AutoField(primary_key=True, db_column='result_id')
    match = models.OneToOneField(Match, db_column='match_id', on_delete=models.CASCADE, related_name='result', verbose_name='Матч')
    winner_team = models.ForeignKey(Team, db_column='winner_team_id', on_delete=models.SET_NULL, blank=True, null=True, verbose_name='Победитель')
    score_team1 = models.IntegerField('Счёт команды 1', default=0)
    score_team2 = models.IntegerField('Счёт команды 2', default=0)
    class Meta:
        db_table = 'result'
        verbose_name = 'результат'
        verbose_name_plural = 'результаты'
        constraints = [
            models.CheckConstraint(condition=Q(score_team1__gte=0), name='score1_nonnegative'),
            models.CheckConstraint(condition=Q(score_team2__gte=0), name='score2_nonnegative'),
        ]
    def __str__(self): return f'{self.match}: {self.score_team1}:{self.score_team2}'
    def clean(self):
        if self.match_id and self.winner_team_id not in (None, self.match.team1_id, self.match.team2_id):
            raise ValidationError('Победитель должен быть участником матча.')


class Application(models.Model):
    tournament = models.ForeignKey(Tournament, on_delete=models.CASCADE, related_name='applications', verbose_name='Турнир')
    team = models.ForeignKey(Team, on_delete=models.PROTECT, related_name='applications', verbose_name='Команда')
    status = models.CharField('Статус', max_length=12, choices=[('pending', 'На рассмотрении'), ('approved', 'Одобрена'), ('rejected', 'Отклонена'), ('withdrawn', 'Отозвана')], default='pending')
    note = models.CharField('Комментарий', max_length=250, blank=True)
    reviewed_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        db_table = 'applications'
        verbose_name = 'заявка'
        verbose_name_plural = 'заявки'
        constraints = [
            models.UniqueConstraint(fields=['tournament', 'team'], name='one_team_application'),
            models.CheckConstraint(condition=Q(status__in=['pending', 'approved', 'rejected', 'withdrawn']), name='valid_application_status'),
        ]


class Map(models.Model):
    name = models.CharField('Название', max_length=32, unique=True)
    class Meta:
        db_table = 'maps'
        verbose_name = 'карта'
        verbose_name_plural = 'карты'
    def __str__(self): return self.name


class MapScore(models.Model):
    match = models.ForeignKey(Match, on_delete=models.CASCADE, related_name='map_scores')
    map = models.ForeignKey(Map, on_delete=models.PROTECT, verbose_name='Карта')
    number = models.PositiveSmallIntegerField('Номер карты')
    score1 = models.PositiveSmallIntegerField('Раунды команды 1', validators=[MaxValueValidator(60)])
    score2 = models.PositiveSmallIntegerField('Раунды команды 2', validators=[MaxValueValidator(60)])
    class Meta:
        db_table = 'map_scores'
        ordering = ['number']
        constraints = [
            models.UniqueConstraint(fields=['match', 'number'], name='unique_map_number'),
            models.UniqueConstraint(fields=['match', 'map'], name='unique_match_map'),
            models.CheckConstraint(condition=Q(score1__lte=60, score2__lte=60)&~Q(score1=F('score2')), name='valid_map_score'),
        ]


class PlayerStat(models.Model):
    match = models.ForeignKey(Match, on_delete=models.CASCADE, related_name='player_stats')
    player = models.ForeignKey(Player, on_delete=models.PROTECT, related_name='stats', verbose_name='Игрок')
    kills = models.PositiveSmallIntegerField('Убийства', validators=[MaxValueValidator(200)])
    deaths = models.PositiveSmallIntegerField('Смерти', validators=[MaxValueValidator(200)])
    assists = models.PositiveSmallIntegerField('Помощь', default=0, validators=[MaxValueValidator(200)])
    class Meta:
        db_table = 'player_stats'
        constraints = [models.UniqueConstraint(fields=['match', 'player'], name='one_player_stat_per_match')]


class AuditLog(models.Model):
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    action = models.CharField(max_length=32)
    entity = models.CharField(max_length=32)
    object_id = models.PositiveIntegerField()
    description = models.CharField(max_length=250)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        db_table = 'audit_log'
        ordering = ['-created_at']
