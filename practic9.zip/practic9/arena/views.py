from functools import wraps
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView
from django.core.cache import cache
from django.core.exceptions import PermissionDenied, ValidationError
from django.core.paginator import Paginator
from django.db import IntegrityError, transaction
from django.db.models import Q, Count, Sum
from django.db.models.deletion import ProtectedError
from django.forms import formset_factory
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_POST
from .models import Application, AuditLog, Game, Match, Player, PlayerStat, Team, Tournament, REGIONS, COUNTRIES
from .forms import RegisterForm, TeamForm, PlayerForm, TournamentForm, ApplicationForm, MapResultForm, MatchScheduleForm, StatForm
from . import services


def role_required(*roles):
    def decorator(view):
        @login_required
        @wraps(view)
        def wrapped(request, *args, **kwargs):
            if request.user.role not in roles: raise PermissionDenied('Недостаточно прав для этой операции.')
            return view(request, *args, **kwargs)
        return wrapped
    return decorator


def paginate(request, queryset):
    return Paginator(queryset, 18).get_page(request.GET.get('page'))


def order(request, queryset, allowed, default):
    # Only predefined ORM expressions can reach ORDER BY, including multi-sort.
    terms = [allowed[x] for x in request.GET.get('sort', '').split(',') if x in allowed]
    return queryset.order_by(*(terms or default), 'pk')


def home(request):
    matches = Match.objects.select_related('team1', 'team2', 'tournament', 'result').exclude(team1=None).exclude(team2=None)
    feature = matches.filter(status='live').order_by('match_date').first() or matches.filter(status='scheduled').order_by('match_date').first()
    events = Tournament.objects.filter(status__in=['ongoing', 'registration']).select_related('game').order_by('start_date')
    return render(request, 'home.html', {
        'nav': 'home', 'feature': feature,
        'upcoming': matches.exclude(status='finished').order_by('match_date')[:6],
        'results': matches.filter(status='finished').order_by('-match_date')[:5],
        'top_teams': Team.objects.select_related('game').order_by('-points', 'name')[:5],
        'tournaments': events[:4],
        'counts': {'teams': Team.objects.count(), 'players': Player.objects.count(), 'tournaments': Tournament.objects.count(), 'live': Match.objects.filter(status='live').count()},
    })


def tournament_list(request):
    qs = Tournament.objects.select_related('organization', 'game')
    if not (request.user.is_authenticated and request.user.is_admin): qs = qs.exclude(status='draft')
    q = request.GET.get('q', '').strip()
    if q: qs = qs.filter(Q(name__icontains=q)|Q(organization__name__icontains=q)|Q(game__name__icontains=q))
    for key, field in [('status', 'status'), ('region', 'region'), ('format', 'best_of')]:
        val = request.GET.get(key)
        if val and (key != 'format' or val in ('1', '3')): qs = qs.filter(**{field: val})
    qs = order(request, qs, {'date':'start_date', '-date':'-start_date', 'name':'name', '-prize':'-prize_pool', 'prize':'prize_pool'}, ['-start_date'])
    return render(request, 'tournaments.html', {'nav':'tournaments', 'page_obj':paginate(request, qs), 'statuses':Tournament.Status.choices, 'regions':REGIONS})


def tournament_detail(request, pk):
    t = get_object_or_404(Tournament.objects.select_related('organization', 'manager', 'game'), pk=pk)
    editable = t.editable_by(request.user)
    if t.status == 'draft' and not editable: raise PermissionDenied('Это неопубликованный черновик турнира.')
    rounds = []
    qs = t.matches.select_related('team1','team2','result').order_by('round_number','slot','pk')
    for num in qs.order_by('round_number').values_list('round_number', flat=True).distinct():
        group = list(qs.filter(round_number=num))
        rounds.append({'name': group[0].stage or 'Матчи', 'matches':group})
    apps = t.applications.select_related('team','team__owner').order_by('created_at')
    own = apps.filter(team__owner=request.user) if request.user.is_authenticated else apps.none()
    return render(request, 'tournament_detail.html', {'nav':'tournaments','t':t,'editable':editable,'rounds':rounds,
        'approved':apps.filter(status='approved'), 'apps':apps if editable else own,
        'application_form':ApplicationForm(user=request.user,tournament=t) if request.user.is_authenticated and t.status=='registration' else None})


@role_required('manager', 'admin')
@transaction.atomic
def tournament_form(request, pk=None):
    obj = get_object_or_404(Tournament.objects.select_for_update(), pk=pk) if pk else Tournament(manager=request.user)
    if pk: services.require_manager(request.user, obj)
    form = TournamentForm(request.POST or None, instance=obj, user=request.user)
    if request.method == 'POST' and form.is_valid():
        with transaction.atomic():
            obj = form.save(commit=False)
            if request.user.is_admin: obj.manager = form.cleaned_data['manager']
            elif not pk: obj.manager = request.user
            obj.save()
            services.audit(request.user, 'update' if pk else 'create', obj, f'Турнир: {obj.name}')
        messages.success(request, 'Турнир сохранён.')
        return redirect('tournament', pk=obj.pk)
    return render(request,'form.html',{'form':form,'title':'Редактирование турнира' if pk else 'Новый турнир','back':reverse('tournament',args=[pk]) if pk else reverse('tournaments')})


@role_required('manager','admin')
@require_POST
@transaction.atomic
def tournament_action(request, pk, action):
    t = get_object_or_404(Tournament.objects.select_for_update(), pk=pk)
    services.require_manager(request.user, t)
    try:
        if action == 'open': services.open_registration(request.user, pk)
        elif action == 'seed': services.generate_bracket(request.user, pk, request.POST.get('method', 'rating'))
        elif action == 'delete':
            if t.status not in ('draft', 'registration') or t.matches.exists():
                raise ValidationError('Удаление доступно до формирования сетки.')
            services.audit(request.user, 'delete', t, f'Удалён турнир {t.name}')
            t.delete()
            messages.success(request,'Турнир удалён.')
            return redirect('cabinet')
        else: raise ValidationError('Неизвестное действие.')
        messages.success(request,'Действие выполнено.')
    except ValidationError as e: messages.error(request, ' '.join(e.messages))
    return redirect('tournament', pk=pk)


@login_required
@require_POST
def apply(request, pk):
    t = get_object_or_404(Tournament, pk=pk)
    form = ApplicationForm(request.POST, user=request.user, tournament=t)
    try:
        if not form.is_valid(): raise ValidationError('Выберите свою команду и проверьте комментарий.')
        services.apply_to_tournament(request.user, pk, form.cleaned_data['team'].pk, form.cleaned_data['note'])
        messages.success(request, 'Заявка отправлена менеджеру турнира.')
    except ValidationError as e: messages.error(request, ' '.join(e.messages))
    return redirect('tournament', pk=pk)


@login_required
@require_POST
def application_action(request, pk, action):
    obj = get_object_or_404(Application, pk=pk)
    try:
        if action == 'withdraw': services.withdraw_application(request.user, pk)
        else: services.review_application(request.user, pk, action)
        messages.success(request, 'Статус заявки изменён.')
    except ValidationError as e: messages.error(request,' '.join(e.messages))
    return redirect('tournament', pk=obj.tournament_id)


def match_queryset(request):
    qs = Match.objects.select_related('team1','team2','tournament','result').exclude(tournament__status='draft')
    q = request.GET.get('q','').strip()
    if q: qs = qs.filter(Q(team1__name__icontains=q)|Q(team2__name__icontains=q)|Q(tournament__name__icontains=q)|Q(stage__icontains=q))
    if request.GET.get('status') in ('scheduled','live','finished'): qs = qs.filter(status=request.GET['status'])
    if request.GET.get('format') in ('1','3'): qs = qs.filter(tournament__best_of=request.GET['format'])
    if request.GET.get('region'): qs = qs.filter(tournament__region=request.GET['region'])
    return order(request, qs, {'date':'match_date','-date':'-match_date','tournament':'tournament__name','stage':'stage'}, ['match_date'])


def match_list(request):
    return render(request,'matches.html',{'nav':'matches','page_obj':paginate(request,match_queryset(request)),'regions':REGIONS})


def match_detail(request,pk):
    m = get_object_or_404(Match.objects.select_related('team1','team2','tournament','result'),pk=pk)
    editable=m.tournament.editable_by(request.user)
    if m.tournament.status=='draft' and not editable: raise PermissionDenied
    return render(request,'match_detail.html',{'nav':'matches','m':m,'editable':editable,
        'stats':m.player_stats.select_related('player','player__team').order_by('-kills')})


@role_required('manager','admin')
def match_result(request,pk):
    m = get_object_or_404(Match.objects.select_related('tournament','team1','team2'),pk=pk)
    services.require_manager(request.user,m.tournament)
    if m.status=='finished' and not request.user.is_admin: raise PermissionDenied('Исправить результат может администратор.')
    initial=list(m.map_scores.values('map','score1','score2'))
    FormSet=formset_factory(MapResultForm,extra=m.tournament.best_of,min_num=0,max_num=m.tournament.best_of,validate_max=True)
    forms=FormSet(request.POST or None,initial=initial,prefix='maps')
    if request.method=='POST' and forms.is_valid():
        try:
            services.record_result(request.user,pk,[f.cleaned_data for f in forms if f.cleaned_data.get('map')])
            messages.success(request,'Результат сохранён. Победитель прошёл в следующий раунд.')
            return redirect('match',pk=pk)
        except ValidationError as e: messages.error(request,' '.join(e.messages))
    return render(request,'result_form.html',{'m':m,'formset':forms})


@role_required('manager','admin')
@transaction.atomic
def match_schedule(request,pk):
    tournament_id=get_object_or_404(Match,pk=pk).tournament_id
    get_object_or_404(Tournament.objects.select_for_update(),pk=tournament_id)
    m=get_object_or_404(Match.objects.select_for_update(),pk=pk)
    services.require_manager(request.user,m.tournament)
    if m.status=='finished': raise PermissionDenied('Завершённый матч нельзя вернуть в расписание.')
    form=MatchScheduleForm(request.POST or None,instance=m)
    if request.method=='POST' and form.is_valid():
        form.save()
        services.audit(request.user,'schedule',m,'Изменено расписание / статус матча')
        return redirect('match',pk=pk)
    return render(request,'form.html',{'form':form,'title':'Расписание матча','back':reverse('match',args=[pk])})


@role_required('manager','admin')
def match_stat(request,pk):
    m=get_object_or_404(Match.objects.select_related('tournament'),pk=pk)
    services.require_manager(request.user,m.tournament)
    form=StatForm(request.POST or None,match=m)
    if request.method=='POST' and form.is_valid():
        data=form.cleaned_data
        PlayerStat.objects.update_or_create(match=m,player=data['player'],defaults={k:data[k] for k in ['kills','deaths','assists']})
        services.audit(request.user,'stat',m,f'Обновлена статистика: {data["player"]}')
        messages.success(request,'Статистика игрока сохранена.')
        return redirect('match',pk=pk)
    return render(request,'form.html',{'form':form,'title':'Статистика игрока за серию','subtitle':'Повторный выбор игрока обновляет его существующую запись.','back':reverse('match',args=[pk])})


def team_list(request):
    qs=Team.objects.select_related('game').annotate(roster_size=Count('players'))
    q=request.GET.get('q','').strip()
    if q: qs=qs.filter(Q(name__icontains=q)|Q(tag__icontains=q)|Q(coach__icontains=q))
    if request.GET.get('country'): qs=qs.filter(country=request.GET['country'])
    if request.GET.get('game','').isdigit(): qs=qs.filter(game_id=request.GET['game'])
    qs=order(request,qs,{'points':'-points','name':'name','country':'country','players':'-roster_size'},['-points','name'])
    return render(request,'teams.html',{'nav':'teams','page_obj':paginate(request,qs),'countries':COUNTRIES,'games':Game.objects.order_by('name')})


def team_detail(request,pk):
    t=get_object_or_404(Team.objects.select_related('game','owner'),pk=pk)
    matches=Match.objects.filter(Q(team1=t)|Q(team2=t)).select_related('team1','team2','result','tournament').order_by('-match_date')[:10]
    return render(request,'team_detail.html',{'nav':'teams','team':t,'editable':t.editable_by(request.user),'matches':matches,
        'wins':t.result_set.count(),'played':Match.objects.filter(Q(team1=t)|Q(team2=t),status='finished').count()})


@login_required
@transaction.atomic
def team_form(request,pk=None):
    obj=get_object_or_404(Team.objects.select_for_update(),pk=pk) if pk else Team(owner=request.user)
    if pk and not obj.editable_by(request.user): raise PermissionDenied('Это команда другого капитана.')
    form=TeamForm(request.POST or None,instance=obj)
    if request.method=='POST' and form.is_valid():
        obj=form.save()
        services.audit(request.user,'update' if pk else 'create',obj,f'Команда {obj.name}')
        return redirect('team',pk=obj.pk)
    return render(request,'form.html',{'form':form,'title':'Редактирование команды' if pk else 'Новая команда','back':reverse('team',args=[pk]) if pk else reverse('teams')})


@login_required
@transaction.atomic
def player_form(request,team_pk,pk=None):
    team=get_object_or_404(Team.objects.select_for_update(),pk=team_pk)
    if not team.editable_by(request.user): raise PermissionDenied('Редактировать состав может капитан или администратор.')
    if team.roster_locked: raise PermissionDenied('Состав зафиксирован на время турнира.')
    obj=get_object_or_404(Player,pk=pk,team=team) if pk else Player(team=team)
    form=PlayerForm(request.POST or None,instance=obj)
    if request.method=='POST' and form.is_valid():
        obj=form.save()
        services.audit(request.user,'update' if pk else 'create',obj,f'Игрок {obj.nickname}')
        return redirect('team',pk=team_pk)
    return render(request,'form.html',{'form':form,'title':'Редактирование игрока' if pk else 'Добавить игрока','back':reverse('team',args=[team_pk])})


@login_required
@require_POST
@transaction.atomic
def delete_entity(request,kind,pk):
    if kind=='team':
        obj=get_object_or_404(Team.objects.select_for_update(),pk=pk)
        if not obj.editable_by(request.user): raise PermissionDenied
        if obj.players.exists():
            messages.error(request,'Сначала удалите игроков из состава. Игроков со статистикой удалить нельзя: они связаны с историей матчей.')
            return redirect('team',pk=pk)
        back=reverse('teams')
    elif kind=='player':
        obj=get_object_or_404(Player.objects.select_related('team'),pk=pk)
        if obj.team_id: get_object_or_404(Team.objects.select_for_update(),pk=obj.team_id)
        if not obj.team or not obj.team.editable_by(request.user): raise PermissionDenied
        if obj.team.roster_locked: raise PermissionDenied('Состав зафиксирован на время турнира.')
        back=reverse('team',args=[obj.team_id])
    else: raise PermissionDenied
    try:
        with transaction.atomic():
            services.audit(request.user,'delete',obj,str(obj))
            obj.delete()
        messages.success(request,'Запись удалена.')
    except ProtectedError:
        messages.error(request,'Запись связана с матчами, заявками или статистикой. Удаление нарушит историю турнира.')
        back=reverse('team',args=[obj.pk]) if kind=='team' else back
    return redirect(back)


def player_list(request):
    qs=Player.objects.select_related('team').annotate(total_kills=Sum('stats__kills'),total_deaths=Sum('stats__deaths'),played=Count('stats'))
    q=request.GET.get('q','').strip()
    if q: qs=qs.filter(Q(nickname__icontains=q)|Q(full_name__icontains=q)|Q(team__name__icontains=q))
    if request.GET.get('country'): qs=qs.filter(country=request.GET['country'])
    if request.GET.get('position'): qs=qs.filter(position=request.GET['position'])
    qs=order(request,qs,{'name':'nickname','kills':'-total_kills','matches':'-played','team':'team__name'},['-total_kills','nickname'])
    return render(request,'players.html',{'nav':'players','page_obj':paginate(request,qs),'countries':COUNTRIES,'positions':Player._meta.get_field('position').choices})


@login_required
def cabinet(request):
    u=request.user
    own=u.teams.annotate(roster_size=Count('players')).order_by('name')
    tournaments=Tournament.objects.filter(manager=u).order_by('-pk')
    apps=Application.objects.select_related('tournament','team').filter(team__owner=u).order_by('-created_at')
    if u.is_admin: tournaments=Tournament.objects.all().order_by('-pk')
    return render(request,'cabinet.html',{'nav':'cabinet','teams':own,'tournaments':tournaments[:40],'apps':apps[:40]})


def register(request):
    if request.user.is_authenticated: return redirect('cabinet')
    form=RegisterForm(request.POST or None)
    if request.method=='POST' and form.is_valid():
        user=form.save()
        login(request,user)
        messages.success(request,'Аккаунт создан. Теперь можно собрать команду.')
        return redirect('cabinet')
    return render(request,'registration/register.html',{'form':form})


class ThrottledLoginView(LoginView):
    template_name='registration/login.html'
    def post(self,request,*args,**kwargs):
        import hashlib
        value=f'{request.META.get("REMOTE_ADDR", "")}|{request.POST.get("username", "").lower()}'
        self.rate_key='login:'+hashlib.sha256(value.encode()).hexdigest()
        if cache.get(self.rate_key,0)>=10:
            form=self.get_form()
            form.add_error(None,'Слишком много попыток. Повторите вход через 15 минут.')
            return self.render_to_response(self.get_context_data(form=form),status=429)
        return super().post(request,*args,**kwargs)
    def form_invalid(self,form):
        cache.set(self.rate_key,cache.get(self.rate_key,0)+1,900)
        return super().form_invalid(form)
    def form_valid(self,form):
        cache.delete(self.rate_key)
        return super().form_valid(form)


@role_required('admin')
def audit_log(request):
    qs=AuditLog.objects.select_related('actor')
    if request.GET.get('q'): qs=qs.filter(Q(description__icontains=request.GET['q'])|Q(actor__username__icontains=request.GET['q']))
    return render(request,'audit.html',{'nav':'cabinet','page_obj':paginate(request,qs)})


def error_403(request,exception=None):
    return render(request,'error.html',{'code':'403','title':'Доступ ограничен','text':str(exception) or 'Для этого действия требуется другая роль.'},status=403)

def error_404(request,exception=None):
    return render(request,'error.html',{'code':'404','title':'Страница не найдена','text':'Проверьте адрес или вернитесь на главную.'},status=404)
