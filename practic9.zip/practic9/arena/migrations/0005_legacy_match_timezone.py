from django.db import migrations


def normalize_legacy_timestamp(apps,schema_editor):
    # Original `tables` uses TIMESTAMP without a zone. Django expects timestamptz.
    # Treat legacy wall-clock values as Yekaterinburg time; fresh schemas need no change.
    if schema_editor.connection.vendor!='postgresql': return
    with schema_editor.connection.cursor() as cursor:
        cursor.execute('''SELECT data_type FROM information_schema.columns
            WHERE table_schema=current_schema() AND table_name=%s AND column_name=%s''', ['matches','match_date'])
        row=cursor.fetchone()
        if row and row[0]=='timestamp without time zone':
            cursor.execute("ALTER TABLE matches ALTER COLUMN match_date TYPE timestamp with time zone USING match_date AT TIME ZONE 'Asia/Yekaterinburg'")


class Migration(migrations.Migration):
    dependencies=[('arena','0004_alter_tournament_organization')]
    operations=[migrations.RunPython(normalize_legacy_timestamp,migrations.RunPython.noop)]
