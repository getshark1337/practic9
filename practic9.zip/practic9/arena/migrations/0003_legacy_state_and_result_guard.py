from django.db import migrations


def adopt_legacy(apps, schema_editor):
    Match=apps.get_model('arena','Match')
    Tournament=apps.get_model('arena','Tournament')
    Match.objects.filter(result__isnull=False).update(status='finished')
    for t in Tournament.objects.filter(matches__isnull=False).distinct():
        t.status='ongoing' if t.matches.exclude(status='finished').exists() else 'finished'
        t.save(update_fields=['status'])


def install_guard(apps,schema_editor):
    vendor=schema_editor.connection.vendor
    if vendor=='postgresql':
        schema_editor.execute('''
            CREATE OR REPLACE FUNCTION frag_validate_result() RETURNS TRIGGER AS $$
            BEGIN
              IF NEW.winner_team_id IS NOT NULL AND NOT EXISTS (
                SELECT 1 FROM matches m WHERE m.match_id=NEW.match_id AND (
                  (NEW.winner_team_id=m.team1_id AND NEW.score_team1>NEW.score_team2) OR
                  (NEW.winner_team_id=m.team2_id AND NEW.score_team2>NEW.score_team1)
                )
              ) THEN RAISE EXCEPTION 'Invalid match winner or score'; END IF;
              RETURN NEW;
            END; $$ LANGUAGE plpgsql;
        ''')
        schema_editor.execute('CREATE TRIGGER trg_frag_result BEFORE INSERT OR UPDATE ON result FOR EACH ROW EXECUTE FUNCTION frag_validate_result()')
    elif vendor=='sqlite':
        for op in ['INSERT','UPDATE']:
            schema_editor.execute(f'''CREATE TRIGGER trg_frag_result_{op.lower()}
              BEFORE {op} ON result WHEN NEW.winner_team_id IS NOT NULL AND NOT EXISTS (
                SELECT 1 FROM matches m WHERE m.match_id=NEW.match_id AND (
                  (NEW.winner_team_id=m.team1_id AND NEW.score_team1>NEW.score_team2) OR
                  (NEW.winner_team_id=m.team2_id AND NEW.score_team2>NEW.score_team1)
                )
              ) BEGIN SELECT RAISE(ABORT, 'Invalid match winner or score'); END''')


def remove_guard(apps,schema_editor):
    if schema_editor.connection.vendor=='postgresql':
        schema_editor.execute('DROP TRIGGER IF EXISTS trg_frag_result ON result')
        schema_editor.execute('DROP FUNCTION IF EXISTS frag_validate_result()')
    elif schema_editor.connection.vendor=='sqlite':
        for op in ['insert','update']: schema_editor.execute(f'DROP TRIGGER IF EXISTS trg_frag_result_{op}')


class Migration(migrations.Migration):
    dependencies=[('arena','0002_application_auditlog_map_mapscore_playerstat_and_more')]
    operations=[migrations.RunPython(adopt_legacy,migrations.RunPython.noop),migrations.RunPython(install_guard,remove_guard)]
