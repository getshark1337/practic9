from pathlib import Path
from django.core.management.base import BaseCommand
from arena.reports import backup_stream


class Command(BaseCommand):
    help='Создать согласованную резервную копию текущей БД (SQLite или PostgreSQL).'
    def add_arguments(self,parser):
        parser.add_argument('destination',nargs='?',default='backups')
    def handle(self,*args,**options):
        from django.utils import timezone
        stream,suffix=backup_stream()
        target=Path(options['destination'])
        if not target.suffix:
            target.mkdir(parents=True,exist_ok=True)
            target=target/f'arena-{timezone.now().strftime("%Y%m%d-%H%M%S")}.{suffix}'
        else: target.parent.mkdir(parents=True,exist_ok=True)
        with stream, target.open('wb') as out:
            for block in iter(lambda:stream.read(65536),b''): out.write(block)
        self.stdout.write(str(target.resolve()))
