"""Add a clearly synthetic, reproducible dataset without deleting legacy data."""
import random
from datetime import timedelta
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.utils import timezone
from accounts.models import User
from arena.models import Organization, Game, Team, Player, Tournament, Application, Match, Map, PlayerStat, COUNTRIES
from arena.services import generate_bracket, record_result


class Command(BaseCommand):
    help = 'Добавить учебные аккаунты и 100+ записей в каждую из семи исходных таблиц.'

    @transaction.atomic
    def handle(self, *args, **options):
        if Tournament.objects.filter(name='FRAG Open 001').exists():
            self.stdout.write('Учебные данные уже загружены. Повторное заполнение не требуется.')
            return
        if User.objects.filter(username__in=['admin', 'manager', 'user']).exists():
            raise CommandError('Логины admin/manager/user уже заняты. Заполнение остановлено; данные не изменены.')
        rng=random.Random(20261028)
        admin=User.objects.create_user(username='admin',email='admin@example.test',display_name='Администратор',role='admin',password='ArenaAdmin!2026')
        manager=User.objects.create_user(username='manager',email='manager@example.test',display_name='Организатор',role='manager',password='ArenaManager!2026')
        user=User.objects.create_user(username='user',email='user@example.test',display_name='Капитан команды',password='ArenaUser!2026')
        people=[User(username=f'demo_{i:03}',email=f'demo{i:03}@example.test',display_name=f'Капитан {i:03}',password='!') for i in range(120)]
        User.objects.bulk_create(people)
        orgs=[Organization(name=f'FRAG Events {i+1:03}',email=f'events{i+1:03}@example.test',phone=f'+7 900 100 {i:04}',address=f'Учебный адрес {i+1}') for i in range(120)]
        Organization.objects.bulk_create(orgs)
        game,_=Game.objects.get_or_create(name='Counter-Strike 2',defaults={'genre':'Tactical FPS','developer':'Valve'})
        Game.objects.bulk_create([Game(name=f'Учебная дисциплина {i:03}',genre='Тестовый справочник',developer='Учебные данные') for i in range(2,101)])
        maps=[Map.objects.get_or_create(name=name)[0] for name in ['Mirage','Inferno','Nuke','Ancient','Anubis','Dust2','Vertigo']]
        names=['Northstar','Phantom','Ember','Vertex','Polar','Vortex','Apex','Orbit','Cobalt','Quantum','Nova','Horizon']
        teams=[]
        for i in range(120):
            name=names[i] if i<len(names) else f'{names[i%len(names)]} Academy {i//len(names):02}'
            teams.append(Team(name=name,tag=f'F{i:03}',country=COUNTRIES[i%len(COUNTRIES)][0],coach=f'Coach {i+1:03}',game=game,owner=user if i<2 else people[i],points=max(20,1200-i*9)))
        Team.objects.bulk_create(teams)
        players=[]
        positions=['igl','awper','rifler','support','entry']
        for i,team in enumerate(teams):
            for n in range(5):
                players.append(Player(team=team,nickname=f'{team.tag.lower()}_{["ace","scope","flash","clutch","entry"][n]}',full_name=f'Игрок {i+1:03}-{n+1}',country=team.country,position=positions[n]))
        Player.objects.bulk_create(players)
        roster={team.pk:[] for team in teams}
        for p in players: roster[p.team_id].append(p)
        now=timezone.localdate()
        stats=[]
        for i in range(120):
            active=i<20
            completed=20<=i<100
            date=now+timedelta(days=i//2) if active else now-timedelta(days=120-i) if completed else now+timedelta(days=i-90)
            t=Tournament.objects.create(name=f'FRAG Open {i+1:03}',organization=orgs[i],manager=manager,game=game,
                start_date=date,end_date=date+timedelta(days=3),prize_pool=(20+i%12*5)*1000,
                capacity=8 if i<110 else [8,16,32][i%3],best_of=1 if i%5==4 else 3,
                region=['online','europe','cis','asia','americas'][i%5],status='registration' if i<110 else 'draft',
                description='Учебный турнир по Counter-Strike 2. Сетка на выбывание, состав от пяти игроков. Все команды, матчи и результаты в демонстрационном наборе вымышлены.')
            pool=[teams[(i*7+j)%len(teams)] for j in range(8)]
            if i<110:
                Application.objects.bulk_create([Application(tournament=t,team=team,status='approved' if (i<100 or n<6) else 'pending',reviewed_by=manager if (i<100 or n<6) else None) for n,team in enumerate(pool)])
            if i<100:
                generate_bracket(manager,t.pk)
                for m in t.matches.order_by('round_number','slot'):
                    if active and not (i==0 and m.round_number==1 and m.slot<=2): continue
                    winner=rng.randrange(2)
                    total=1 if t.best_of==1 else rng.choice([2,3])
                    outcomes=[winner] if total==1 else [winner,winner] if total==2 else [1-winner,winner,winner]
                    rows=[{'map':maps[n],'score1':13 if w==0 else rng.randint(3,11),'score2':13 if w==1 else rng.randint(3,11)} for n,w in enumerate(outcomes)]
                    record_result(manager,m.pk,rows)
                    m.refresh_from_db()
                    for tid in (m.team1_id,m.team2_id):
                        for p in roster[tid]:
                            stats.append(PlayerStat(match=m,player=p,kills=rng.randint(8,28)*total,deaths=rng.randint(8,24)*total,assists=rng.randint(2,9)*total))
                if i==0:
                    t.matches.filter(round_number=1,slot=3).update(status='live',match_date=timezone.now())
        PlayerStat.objects.bulk_create(stats,batch_size=300)
        self.stdout.write(self.style.SUCCESS('Учебные данные добавлены. admin / manager / user — пароли см. README.md.'))
        from arena.models import Result
        for model in [Organization,Game,Team,Player,Tournament,Match,Result,Application,PlayerStat]:
            self.stdout.write(f'{model._meta.db_table}: {model.objects.count()}')
