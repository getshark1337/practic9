import io
from datetime import timedelta
from django.core.exceptions import PermissionDenied, ValidationError
from django.db import DatabaseError, IntegrityError, transaction
from django.test import TestCase, Client
from django.urls import reverse
from django.utils import timezone
from openpyxl import load_workbook
from accounts.models import User
from .models import Organization, Game, Team, Player, Tournament, Application, Match, Map, Result
from .services import apply_to_tournament, review_application, generate_bracket, open_registration, record_result, withdraw_application, validate_map_results


class TournamentTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.admin=User.objects.create_user(username='root',email='root@example.test',role='admin',display_name='Admin')
        cls.manager=User.objects.create_user(username='manager',email='manager@example.test',role='manager',display_name='Manager')
        cls.other=User.objects.create_user(username='other',email='other@example.test',role='manager',display_name='Other')
        cls.user=User.objects.create_user(username='captain',email='captain@example.test',display_name='Captain')
        cls.org=Organization.objects.create(name='Test Events')
        cls.game=Game.objects.create(name='Counter-Strike 2')
        cls.maps=[Map.objects.create(name=n) for n in ['Mirage','Nuke','Inferno']]
        cls.teams=[]
        for i in range(8):
            team=Team.objects.create(name=f'Team {i}',tag=f'T{i}',game=cls.game,owner=cls.user,country='Россия',points=100-i)
            Player.objects.bulk_create([Player(team=team,nickname=f'p{i}_{j}',country='Россия') for j in range(5)])
            cls.teams.append(team)
        cls.t=Tournament.objects.create(name='Test Cup',organization=cls.org,manager=cls.manager,game=cls.game,start_date=timezone.localdate(),end_date=timezone.localdate()+timedelta(days=3))

    def seed(self):
        open_registration(self.manager,self.t.pk)
        for team in self.teams:
            a=apply_to_tournament(self.user,self.t.pk,team.pk)
            review_application(self.manager,a.pk,'approved')
        generate_bracket(self.manager,self.t.pk)

    def results(self,second=False):
        return [{'map':m,'score1':8 if second else 13,'score2':13 if second else 8} for m in self.maps[:2]]

    def test_full_user_manager_admin_process_and_champion(self):
        self.seed()
        self.assertEqual(self.t.matches.count(),7)
        first=self.t.matches.get(round_number=1,slot=1)
        record_result(self.manager,first.pk,self.results())
        record_result(self.admin,first.pk,self.results(second=True))
        semi=self.t.matches.get(round_number=2,slot=1)
        self.assertEqual(semi.team1_id,first.team2_id)
        for m in self.t.matches.order_by('round_number','slot'):
            m.refresh_from_db()
            if m.status!='finished': record_result(self.manager,m.pk,self.results())
        self.t.refresh_from_db()
        self.assertEqual(self.t.status,'finished')
        self.assertEqual(Result.objects.filter(match__tournament=self.t).count(),7)
        final=self.t.matches.get(round_number=3)
        self.assertIn(final.result.winner_team_id,[final.team1_id,final.team2_id])

    def test_user_cannot_publish_or_generate(self):
        with self.assertRaises(PermissionDenied): open_registration(self.user,self.t.pk)
        with self.assertRaises(PermissionDenied): generate_bracket(self.user,self.t.pk)

    def test_manager_cannot_manage_someone_elses_tournament(self):
        with self.assertRaises(PermissionDenied): open_registration(self.other,self.t.pk)

    def test_application_requires_own_team_and_open_registration(self):
        with self.assertRaises(ValidationError): apply_to_tournament(self.user,self.t.pk,self.teams[0].pk)
        open_registration(self.manager,self.t.pk)
        with self.assertRaises(PermissionDenied): apply_to_tournament(self.other,self.t.pk,self.teams[0].pk)

    def test_application_requires_five_players(self):
        self.teams[0].players.first().delete()
        open_registration(self.manager,self.t.pk)
        with self.assertRaises(ValidationError): apply_to_tournament(self.user,self.t.pk,self.teams[0].pk)

    def test_duplicate_application_and_reapply_after_withdrawal(self):
        open_registration(self.manager,self.t.pk)
        a=apply_to_tournament(self.user,self.t.pk,self.teams[0].pk)
        with self.assertRaises(ValidationError): apply_to_tournament(self.user,self.t.pk,self.teams[0].pk)
        withdraw_application(self.user,a.pk)
        a=apply_to_tournament(self.user,self.t.pk,self.teams[0].pk)
        self.assertEqual(a.status,'pending')

    def test_incomplete_bracket_rejected(self):
        open_registration(self.manager,self.t.pk)
        with self.assertRaises(ValidationError): generate_bracket(self.manager,self.t.pk)
        self.assertEqual(self.t.matches.count(),0)

    def test_generate_once(self):
        self.seed()
        with self.assertRaises(ValidationError): generate_bracket(self.manager,self.t.pk)
        self.assertEqual(self.t.matches.count(),7)

    def test_manager_cannot_correct_completed_result(self):
        self.seed()
        m=self.t.matches.get(round_number=1,slot=1)
        record_result(self.manager,m.pk,self.results())
        with self.assertRaises(PermissionDenied): record_result(self.manager,m.pk,self.results(True))

    def test_correction_cannot_break_started_next_match(self):
        self.seed()
        m=self.t.matches.get(round_number=1,slot=1)
        record_result(self.manager,m.pk,self.results())
        self.t.matches.filter(round_number=2,slot=1).update(status='live')
        with self.assertRaises(ValidationError): record_result(self.admin,m.pk,self.results(True))

    def test_invalid_and_incomplete_scores(self):
        for a,b in [(13,12),(12,10),(14,12),(13,13),(60,1),(-1,13)]:
            with self.assertRaises(ValidationError): validate_map_results(1,[{'map':self.maps[0],'score1':a,'score2':b}])
        with self.assertRaises(ValidationError): validate_map_results(3,self.results()[:1])
        with self.assertRaises(ValidationError): validate_map_results(3,[self.results()[0],self.results()[0]])
        self.assertEqual(validate_map_results(1,[{'map':self.maps[0],'score1':16,'score2':14}]),[1,0])

    def test_late_application_rejected(self):
        self.seed()
        with self.assertRaises(ValidationError): withdraw_application(self.user,Application.objects.first().pk)

    def test_registration_never_trusts_role(self):
        response=self.client.post('/register/',{'username':'new_user','display_name':'New','email':'new@example.test','password1':'ComplexPass!72841','password2':'ComplexPass!72841','role':'admin','is_superuser':'1'})
        self.assertEqual(response.status_code,302)
        u=User.objects.get(username='new_user')
        self.assertEqual(u.role,'user')
        self.assertFalse(u.is_staff)
        self.assertFalse(u.is_superuser)
        self.assertNotEqual(u.password,'ComplexPass!72841')

    def test_owner_checks_and_immutable_id_in_forms(self):
        self.client.force_login(self.other)
        self.assertEqual(self.client.get(reverse('team_edit',args=[self.teams[0].pk])).status_code,403)
        self.client.force_login(self.user)
        self.client.post(reverse('team_edit',args=[self.teams[0].pk]),{'name':'Edited','tag':'EDIT','country':'Россия','game':self.game.pk,'id':999999,'owner':self.other.pk,'points':999999})
        team=Team.objects.get(pk=self.teams[0].pk)
        self.assertEqual(team.name,'Edited')
        self.assertEqual(team.owner_id,self.user.pk)
        self.assertEqual(team.points,100)
        self.assertFalse(Team.objects.filter(pk=999999).exists())

    def test_csrf_and_get_cannot_mutate(self):
        c=Client(enforce_csrf_checks=True)
        c.force_login(self.manager)
        url=reverse('tournament_action',args=[self.t.pk,'open'])
        self.assertEqual(c.get(url).status_code,405)
        self.assertEqual(c.post(url).status_code,403)

    def test_sql_injection_search_and_sort_are_data(self):
        response=self.client.get('/teams/',{'q':"' OR 1=1; DROP TABLE teams; --",'sort':'name;DROP TABLE teams,country'})
        self.assertEqual(response.status_code,200)
        self.assertEqual(Team.objects.count(),8)

    def test_export_and_formula_injection(self):
        self.seed()
        self.t.name='=HYPERLINK("https://example.test")'
        self.t.save(update_fields=['name'])
        self.client.force_login(self.user)
        response=self.client.get(reverse('tournament_report',args=[self.t.pk]))
        self.assertEqual(response.status_code,200)
        wb=load_workbook(io.BytesIO(response.content))
        self.assertEqual(wb['Турнир']['B2'].data_type,'s')
        self.assertEqual(wb['Матчи'].max_row,8)

    def test_backup_only_admin(self):
        self.client.force_login(self.user)
        self.assertEqual(self.client.get('/backup/').status_code,403)

    def test_user_and_other_manager_cannot_post_results(self):
        self.seed()
        m=self.t.matches.get(round_number=1,slot=1)
        for user in [self.user,self.other]:
            self.client.force_login(user)
            self.assertEqual(self.client.post(reverse('match_result',args=[m.pk])).status_code,403)

    def test_roster_frozen_while_playing(self):
        self.seed()
        self.client.force_login(self.user)
        self.assertEqual(self.client.get(reverse('player_new',args=[self.teams[0].pk])).status_code,403)

    def test_public_and_authenticated_pages_render(self):
        self.seed()
        m=self.t.matches.first()
        for url in ['/', '/tournaments/', '/matches/', '/teams/', '/players/', reverse('tournament',args=[self.t.pk]),reverse('match',args=[m.pk]),reverse('team',args=[self.teams[0].pk]),'/login/','/register/']:
            self.assertEqual(self.client.get(url).status_code,200,url)
        self.client.force_login(self.manager)
        for url in ['/cabinet/',reverse('match_result',args=[m.pk]),reverse('tournament_edit',args=[self.t.pk]),reverse('match_schedule',args=[m.pk])]:
            self.assertEqual(self.client.get(url).status_code,200,url)

    def test_database_constraints(self):
        with self.assertRaises(IntegrityError),transaction.atomic():
            Tournament.objects.filter(pk=self.t.pk).update(capacity=9)
        with self.assertRaises(IntegrityError),transaction.atomic():
            User.objects.filter(pk=self.user.pk).update(role='root')

    def test_database_rejects_winner_that_lost(self):
        self.seed()
        m=self.t.matches.get(round_number=1,slot=1)
        with self.assertRaises(DatabaseError),transaction.atomic():
            # PostgreSQL raises a database exception from its PL/pgSQL trigger;
            # SQLite reports IntegrityError. Neither backend accepts this row.
            Result.objects.create(match=m,winner_team=m.team1,score_team1=0,score_team2=2)
        self.assertFalse(Result.objects.filter(match=m).exists())

    def test_32_team_bracket(self):
        teams=[]
        for i in range(24):
            team=Team.objects.create(name=f'Extra {i}',tag=f'E{i}',game=self.game,owner=self.user)
            teams.append(team)
        Player.objects.bulk_create([Player(team=t,nickname=f'ex{t.pk}_{i}') for t in teams for i in range(5)])
        self.t.capacity=32
        self.t.save(update_fields=['capacity'])
        open_registration(self.manager,self.t.pk)
        for t in self.teams+teams:
            a=apply_to_tournament(self.user,self.t.pk,t.pk)
            review_application(self.manager,a.pk,'approved')
        generate_bracket(self.manager,self.t.pk)
        self.assertEqual(self.t.matches.count(),31)
        self.assertEqual(self.t.matches.filter(round_number=5).count(),1)

    def test_createsuperuser_is_an_application_admin(self):
        u=User.objects.create_superuser(username='super',email='super@example.test',password='OneTime!874265')
        self.assertEqual(u.role,'admin')
        self.assertTrue(u.is_admin)
        self.assertTrue(u.is_staff)

    def test_administration_forms_render(self):
        self.client.force_login(self.admin)
        for url in ['/admin/','/admin/accounts/user/add/',f'/admin/accounts/user/{self.admin.pk}/change/',f'/admin/arena/team/{self.teams[0].pk}/change/',f'/admin/arena/tournament/{self.t.pk}/change/']:
            self.assertEqual(self.client.get(url).status_code,200,url)

    def test_bracket_page_has_one_column_per_round(self):
        self.seed()
        response=self.client.get(reverse('tournament',args=[self.t.pk]))
        self.assertEqual([len(r['matches']) for r in response.context['rounds']],[4,2,1])
