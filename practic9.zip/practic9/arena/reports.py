"""XLSX is generated on demand by the application; user text stays text."""
import io
import sqlite3
import subprocess
import tempfile
import os
from pathlib import Path
from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.http import FileResponse, HttpResponse
from django.shortcuts import get_object_or_404
from django.utils import timezone
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from .models import Tournament
from .views import match_queryset, role_required


def sheet(workbook, title, headers, rows):
    ws=workbook.create_sheet(title)
    ws.append(headers)
    for row in rows:
        ws.append(row)
        for cell in ws[ws.max_row]:
            if isinstance(cell.value,str): cell.data_type='s'  # Prevent formula injection.
    for cell in ws[1]:
        cell.font=Font(color='FFFFFF',bold=True)
        cell.fill=PatternFill('solid',fgColor='163454')
        cell.alignment=Alignment(vertical='center')
    ws.row_dimensions[1].height=26
    ws.freeze_panes='A2'
    ws.auto_filter.ref=ws.dimensions
    for col in ws.columns:
        width=min(48,max(14,max(len(str(c.value or '')) for c in col)+3))
        ws.column_dimensions[col[0].column_letter].width=width
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.alignment=Alignment(vertical='top',wrap_text=True)
    return ws


def send(workbook,filename):
    workbook.remove(workbook['Sheet'])
    data=io.BytesIO()
    workbook.save(data)
    response=HttpResponse(data.getvalue(),content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition']=f'attachment; filename="{filename}.xlsx"'
    response['Cache-Control']='no-store'
    return response


@login_required
def tournament_report(request,pk):
    t=get_object_or_404(Tournament,pk=pk)
    if t.status=='draft' and not t.editable_by(request.user):
        from django.core.exceptions import PermissionDenied
        raise PermissionDenied
    wb=Workbook()
    sheet(wb,'Турнир',['Показатель','Значение'],[
        ['Турнир',t.name],['Данные','Учебный набор / сведения приложения, не статистика HLTV'],
        ['Сформировано',timezone.localtime().strftime('%d.%m.%Y %H:%M')],['Статус',t.get_status_display()],
        ['Начало',str(t.start_date or '')],['Окончание',str(t.end_date or '')],['Призовой фонд, ₽',float(t.prize_pool)],
        ['Команд',t.capacity],['Формат',f'BO{t.best_of}']])
    matches=t.matches.select_related('team1','team2','result').order_by('round_number','slot')
    rows=[]
    for m in matches:
        r=getattr(m,'result',None)
        rows.append([m.pk,m.stage,str(m.team1 or 'TBD'),str(m.team2 or 'TBD'),r.score_team1 if r else '',r.score_team2 if r else '',str(r.winner_team) if r and r.winner_team else '',m.get_status_display()])
    sheet(wb,'Матчи',['ID','Стадия','Команда 1','Команда 2','Счёт 1','Счёт 2','Победитель','Статус'],rows)
    sheet(wb,'Участники',['Команда','Страна','Статус заявки'],[[a.team.name,a.team.country,a.get_status_display()] for a in t.applications.select_related('team').exclude(status='withdrawn')])
    return send(wb,f'tournament-{pk}')


@login_required
def matches_report(request):
    wb=Workbook()
    rows=[]
    for m in match_queryset(request):
        r=getattr(m,'result',None)
        rows.append([m.pk,m.tournament.name,str(m.team1 or 'TBD'),str(m.team2 or 'TBD'),m.stage,
            timezone.localtime(m.match_date).strftime('%d.%m.%Y %H:%M') if m.match_date else '',m.get_status_display(),
            f'{r.score_team1}:{r.score_team2}' if r else ''])
    sheet(wb,'Матчи',['ID','Турнир','Команда 1','Команда 2','Стадия','Время (Екатеринбург)','Статус','Счёт'],rows)
    return send(wb,'matches')


def backup_stream():
    db=settings.DATABASES['default']
    stream=tempfile.TemporaryFile()
    try:
        if db['ENGINE'].endswith('sqlite3'):
            with tempfile.TemporaryDirectory(prefix='frag-backup-') as tmp:
                snapshot=Path(tmp)/'snapshot.sqlite3'
                with sqlite3.connect(str(db['NAME'])) as src, sqlite3.connect(snapshot) as dst:
                    src.backup(dst)
                with snapshot.open('rb') as f:
                    for chunk in iter(lambda:f.read(65536),b''): stream.write(chunk)
            suffix='sqlite3'
        else:
            env=os.environ.copy()
            env['PGPASSWORD']=db.get('PASSWORD','')
            command=['pg_dump','--format=custom','--no-owner','--no-acl','--host',db['HOST'],'--port',str(db['PORT']),'--username',db['USER'],db['NAME']]
            subprocess.run(command,stdout=stream,stderr=subprocess.PIPE,env=env,check=True,timeout=60)
            suffix='dump'
        stream.seek(0)
        return stream,suffix
    except Exception:
        stream.close()
        raise


@role_required('admin')
def backup_download(request):
    try:
        stream,suffix=backup_stream()
    except (FileNotFoundError,subprocess.SubprocessError):
        return HttpResponse('Не удалось создать копию. Установите pg_dump версии вашего сервера и проверьте доступ к БД.',status=503,content_type='text/plain; charset=utf-8')
    response=FileResponse(stream,as_attachment=True,filename=f'arena-{timezone.localdate()}.{suffix}')
    response['Cache-Control']='no-store'
    return response
