from django.contrib import admin
from accounts.models import User
from .models import Organization, Game, Team, Player, Tournament, Match, Result, Application, Map, MapScore, PlayerStat, AuditLog
from .forms import AdminPlayerForm

admin.site.site_header = 'FRAG — администрирование'
admin.site.site_title = 'FRAG Admin'
admin.site.index_title = 'Пользователи, справочники и данные'


class ReadOnlyAdmin(admin.ModelAdmin):
    def has_add_permission(self, request): return False
    def has_change_permission(self, request, obj=None): return False
    def has_delete_permission(self, request, obj=None): return False


@admin.register(Organization)
class OrganizationAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'email', 'phone')
    search_fields = ('name', 'email')
    readonly_fields = ('id',)

@admin.register(Game)
class GameAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'genre', 'developer')
    search_fields = ('name', 'genre')
    readonly_fields = ('id',)

@admin.register(Team)
class TeamAdmin(ReadOnlyAdmin):
    list_display = ('id', 'name', 'tag', 'country', 'owner', 'points')
    search_fields = ('name', 'tag')
    list_filter = ('country', 'game')
    def has_change_permission(self, request, obj=None): return True
    readonly_fields = ('id', 'name', 'tag', 'country', 'coach', 'game')
    fields = ('id', 'name', 'tag', 'country', 'coach', 'game', 'owner', 'points')

@admin.register(Tournament)
class TournamentAdmin(ReadOnlyAdmin):
    list_display = ('id', 'name', 'manager', 'status', 'capacity')
    list_filter = ('status', 'region')
    search_fields = ('name',)
    def has_change_permission(self, request, obj=None): return True
    def get_readonly_fields(self, request, obj=None):
        return [field.name for field in self.model._meta.fields if field.name != 'manager']
    def formfield_for_foreignkey(self, db_field, request, **kwargs):
        if db_field.name == 'manager': kwargs['queryset'] = User.objects.filter(role__in=['manager', 'admin'], is_active=True)
        return super().formfield_for_foreignkey(db_field, request, **kwargs)

@admin.register(Player)
class PlayerAdmin(admin.ModelAdmin):
    form = AdminPlayerForm
    readonly_fields = ('id',)
    list_display = ('id', 'nickname', 'team', 'country', 'position')
    search_fields = ('nickname', 'full_name', 'team__name')
    list_filter = ('country', 'position')
    def has_delete_permission(self, request, obj=None):
        # Bulk deletion cannot bypass per-team roster locks.
        return bool(obj) and (not obj.team or not obj.team.roster_locked) and super().has_delete_permission(request,obj)

@admin.register(Match)
class MatchAdmin(ReadOnlyAdmin):
    list_display = ('id', 'tournament', 'team1', 'team2', 'status')
    list_filter = ('status',)
    search_fields = ('tournament__name', 'team1__name', 'team2__name')

for model in [Result, Application, MapScore, PlayerStat, AuditLog]:
    admin.site.register(model, ReadOnlyAdmin)
admin.site.register(Map)
