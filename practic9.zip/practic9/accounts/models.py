from django.contrib.auth.models import AbstractUser
from django.contrib.auth.models import UserManager
from django.db import models
from django.db.models.functions import Lower


class AppUserManager(UserManager):
    def create_superuser(self, username, email=None, password=None, **extra_fields):
        extra_fields['role'] = 'admin'
        return super().create_superuser(username, email, password, **extra_fields)


class User(AbstractUser):
    class Role(models.TextChoices):
        ADMIN = 'admin', 'Администратор'
        MANAGER = 'manager', 'Менеджер'
        USER = 'user', 'Пользователь'

    email = models.EmailField('Электронная почта', unique=True)
    role = models.CharField('Роль', max_length=10, choices=Role.choices, default=Role.USER)
    display_name = models.CharField('Имя / никнейм', max_length=50)
    objects = AppUserManager()

    class Meta:
        db_table = 'app_users'
        verbose_name = 'пользователь'
        verbose_name_plural = 'пользователи'
        constraints = [
            models.CheckConstraint(condition=models.Q(role__in=['admin', 'manager', 'user']), name='valid_user_role'),
            models.UniqueConstraint(Lower('email'), name='unique_lower_email'),
        ]

    @property
    def is_admin(self):
        return self.is_active and self.role == self.Role.ADMIN

    @property
    def can_manage(self):
        return self.is_active and self.role in (self.Role.ADMIN, self.Role.MANAGER)

    def save(self, *args, **kwargs):
        self.email = self.email.lower()
        self.is_staff = self.role == self.Role.ADMIN
        self.is_superuser = self.is_staff
        super().save(*args, **kwargs)

    def __str__(self):
        return self.display_name or self.username
