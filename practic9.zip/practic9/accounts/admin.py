from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User


@admin.register(User)
class AppUserAdmin(UserAdmin):
    list_display = ('username', 'display_name', 'email', 'role', 'is_active')
    list_filter = ('role', 'is_active')
    search_fields = ('username', 'display_name', 'email')
    ordering = ('username',)
    fieldsets = (
        (None, {'fields': ('id', 'username', 'password')}),
        ('Профиль', {'fields': ('display_name', 'email')}),
        ('Доступ', {'fields': ('role', 'is_active')}),
        ('История', {'fields': ('last_login', 'date_joined')}),
    )
    add_fieldsets = ((None, {'fields': ('username', 'display_name', 'email', 'role', 'password1', 'password2')}),)
    readonly_fields = ('id', 'last_login', 'date_joined')
    def get_readonly_fields(self, request, obj=None):
        fields = list(super().get_readonly_fields(request, obj))
        if obj and obj.pk == request.user.pk: fields += ['role', 'is_active']
        return fields
    def has_delete_permission(self, request, obj=None):
        return (not obj or obj.pk != request.user.pk) and super().has_delete_permission(request, obj)
